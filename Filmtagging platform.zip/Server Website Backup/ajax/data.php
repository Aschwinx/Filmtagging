

<?php  	
	error_reporting(E_ALL & ~E_NOTICE);
	include('../includes/config.inc.php');
	include('../classes/core.class.php');
	include('../classes/login.class.php');
	
	$c_field = $_POST['c-field'];
	$sc_field = $_POST['sc-field'];
	$class_field = $_POST['class-field'];
	$score_field = $_POST['score-field'];

	$false_values = array("--Select a category first--","-- All --", "--Select a category--", "--Select a subcategory--", "--Select a class--");


	$q_category = ($c_field !='' && !in_array($c_field, $false_values) ) ? " AND c_name='".$c_field."'":"";
	$q_subcategory = ($sc_field !='' && !in_array($sc_field, $false_values) ) ? " AND sc_name='".$sc_field."'":"";
	$q_class = ($class_field !='' && !in_array($class_field, $false_values) ) ? " AND class='".$class_field."'":"";
	$q_score = ($score_field !='' && !in_array($score_field, $false_values) ) ? " AND c_score='".$score_field."'":"";

	$strSql = "SELECT * FROM users_annotations WHERE 1=1  $q_category  $q_subcategory  $q_class $q_score";
	echo $strSql;

	$query = $db->query($strSql);

	
	//echo "<br><br>";
	//print_r( $query->errorInfo() );
	//echo "<br><br>";

	$rows = $query->fetchAll();
	//echo "<pre>";
	//print_r( $rows );
	//echo "</pre>";

	
	$return .= "
	<tr>
	<th>User</th>
	<th>Tag</th>
	<th hidden='true'>Tag description</th>
	<th hidden='true'>Start Time</th>
	<th hidden='true'>End Time</th>
	<th>Video title</th>
	<th hidden='true'>Video id</th>
	<th>Score</th>
	<th>Category</th>
	<th>Subcategory</th>
	<th>Classification</th>
	<th hidden='true'>Date</th>
	</tr>
	";

	foreach($rows as $row)
	{
		$return .= "

		<tr>
			<td align='center'>"."<a href='".ROOT."/user/".$row['user_id']."'>".$row['user_id']."</a>"."</td>
			<td>".$row['tag_text']."</td>
			<td hidden='true'>".$row['tag_description']."</td>
			<td hidden='true'>".$row['start_time']."</td>
			<td hidden='true'>".$row['end_time']."</td>
			<td>"."<a href='".ROOT."/video/".$row['video_id']."'>".$row['video_name']."</td>
			<td hidden='true'>".$row['video_id']."</td>
			<td align='center'>".$row['c_score']."</td>
			<td>".$row['c_name']."</td>
			<td>".$row['sc_name']."</td>
			<td>".$row['class']."</td>
			<td hidden='true'>".$row['date']."</td>
		</tr>

		";


	}
	
	echo $return;

?>
