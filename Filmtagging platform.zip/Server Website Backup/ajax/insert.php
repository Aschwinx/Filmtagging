<?php  

	error_reporting(E_ALL & ~E_NOTICE);
	include('../includes/config.inc.php');
	include('../classes/core.class.php');
	include('../classes/login.class.php');

	if ($_POST['c-field'] == "--Select a category--") {
		print_r("empty");
	}
	elseif ($_POST['sc-field'] == "--Select a subcategory--") {
		print_r("empty");
	}
	elseif ($_POST['tag-text'] == "") {
		print_r("empty");
	}
	elseif ($_POST['class-field'] == "--Select a class--") {
		print_r("empty");
	}
	else{

	$video_id = $_POST['movie-id'];	
	$video_name = $_POST['movie-title'];
	$c_field = $_POST['c-field'];
	$sc_field = $_POST['sc-field'];
	$start_time = $_POST['start-time'];
	$end_time = $_POST['start-time'];
	$tag_text= $_POST['tag-text'];
	$tag_description= $_POST['tag-description'];
	$class_field= $_POST['class-field'];
	$user_id = $login->get_user_id();
	$c_score = $_POST['c-score'];	

	$strSql = "INSERT INTO users_annotations (date, user_id, video_name, c_name, sc_name, start_time, end_time, tag_text, tag_description, class, video_id, c_score) 
	VALUES(NOW(),'$user_id','$video_name','$c_field','$sc_field','$start_time','$end_time','$tag_text', '$tag_description','$class_field', '$video_id', '$c_score')";

	$query = $db->query( $strSql );

	if ($query) {
		print_r("success");

	} else{
		echo 'false';
		print_r($query->errorInfo());
	}

	}

?>
