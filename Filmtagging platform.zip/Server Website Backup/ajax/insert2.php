

<?php  
	error_reporting(E_ALL & ~E_NOTICE);
	include('../includes/config.inc.php');
	include('../classes/core.class.php');
	include('../classes/login.class.php');
	

	$ls_score = $_POST['rangevalue1'];
	$cm_score = $_POST['rangevalue2'];
	$et_score = $_POST['rangevalue3'];
	$tr_score = $_POST['rangevalue4'];
	$a_score = $_POST['rangevalue5'];
	$he_score = $_POST['rangevalue6'];
	$lp_score = $_POST['rangevalue7'];
	$s_score = $_POST['rangevalue8'];
	$co_score = $_POST['rangevalue9'];
	$ci_score = $_POST['rangevalue10'];
	$str_score = $_POST['rangevalue11'];
	$st_score = $_POST['rangevalue12'];

	$user_id = $login->get_user_id();

	$strSql = "UPDATE users SET ls_score=$ls_score, cm_score=$cm_score, et_score=$et_score, tr_score=$tr_score, a_score=$a_score,he_score=$he_score, lp_score=$lp_score, s_score=$s_score, co_score=$co_score, ci_score=$ci_score, str_score=$str_score, st_score=$st_score WHERE id=$user_id";

	$query = $db->exec($strSql);

	if ($query) {
		print_r("success");
	} else{
		print_r("error");
	}


	/*else {
		print_r($query->errorInfo()) ;

	}*/

?>
