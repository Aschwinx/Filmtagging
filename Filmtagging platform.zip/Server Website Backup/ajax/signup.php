<?php  

	error_reporting(E_ALL & ~E_NOTICE);
	include('../includes/config.inc.php');
	include('../classes/core.class.php');
	include('../classes/login.class.php');

	if ($_POST['email'] == "") {
		print_r("empty");
	}
	elseif ($_POST['password'] == "") {
		print_r("empty");
	}
	elseif ($_POST['userName'] == "") {
		print_r("empty");
	}
	elseif ($_POST['education'] == "") {
		print_r("empty");
	}
	elseif ($_POST['job'] == "") {
		print_r("empty");
	}
	else{

	$email = $_POST['email'];
	$password = $_POST['password'];
	$userName = $_POST['userName'];
	$education = $_POST['education'];
	$job = $_POST['job'];
	$background = $_POST['background'];
	$ls_score = $_POST['rangevalue1'];
	$cm_score = $_POST['rangevalue2'];
	$et_score = $_POST['rangevalue3'];
	$tr_score = $_POST['rangevalue4'];
	$a_score = $_POST['rangevalue5'];
	$he_score = $_POST['rangevalue6'];
	$lp_score = $_POST['rangevalue7'];
	$s_score = $_POST['rangevalue8'];
	$co_score = $_POST['rangevalue9'];
	$ci_score = $_POST['rangevalue10'];
	$str_score = $_POST['rangevalue11'];
	$st_score = $_POST['rangevalue12'];

	$user_id = $login->get_user_id();

	$strSql = "INSERT INTO users (email, password, userName, education, job, background, ls_score, cm_score, et_score, tr_score, a_score, he_score, lp_score, s_score, co_score, ci_score, str_score, st_score) 
	VALUES('$email','$password','$userName','$education','$job','$background', '$ls_score','$cm_score', '$et_score','$tr_score','$a_score','$he_score','$lp_score','$s_score','$co_score','$ci_score','$str_score','$st_score')";

	$query = $db->query( $strSql );

	if ($query) {
		print_r("success");

	} else{
		echo 'false';
		print_r($query->errorInfo());
	}

	}

?>
