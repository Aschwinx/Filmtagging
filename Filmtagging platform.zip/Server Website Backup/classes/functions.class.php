<?php

class functions_class{
	
	// head functions
	function microtime_float()
	{
	    list($usec, $sec) = explode(" ", microtime());
	    return ((float)$usec + (float)$sec);
	}
	
	function introText($string){
	
		$start = strpos($string, '<p>');
		$end = strpos($string, '</p>', $start);
		$string = substr($string, $start, $end-$start+4);
		
		return $string;
	
	}
	
	function plainText($string){

		$string = html_entity_decode(strip_tags($string));
		
		return $string; 
		
	}


	function cleanup($str, $replace=array(), $delimiter='-') {
		
		if( !empty($replace) ) {
				$str = str_replace((array)$replace, ' ', $str);
		}

		//Alle speciale chars (é, á, ñ, etc, omzetten naar hun best matchende UTF-8 variant: e, a, n)
		$clean = iconv('UTF-8', 'ASCII//TRANSLIT', $str);
		
		//Alle overige vreemde chars verwijderen (', ", &, etc)
		$clean = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $clean);
		
		//Alle chars kleine letters
		$clean = strtolower(trim($clean, '-'));
		
		//custom teken plaatsen voor spaties (bijvoorbeeld na elke ' of " *empty space* ")
		$clean = preg_replace("/[\/_|+ -]+/", $delimiter, $clean);

		return $clean;
		
	}

	function nameShortner($text,$maxlength)
	{
		if(strlen($text) > $maxlength)
		{
			$return = substr($text,0,$maxlength)."..";
		}
		else
		{
			$return = $text;
		}

		return $return;
	}
	

	public function discount($oldprice, $newprice)
	{
		if($oldprice != '' && $newprice !='' || $oldprice != $newprice){
			
			$korting = ($oldprice - $newprice);
			$div = ($oldprice/100);

			if($div !=0 ){
				$korting = $korting / $div;
				return round($korting);
			}

			return 0;

		}
		else{
			return 0;
		}
	}

	function sqlTime() {
		
		echo date('Y-m-d H:i:s');
	
	}


	function checkedSelect($value,$checkValue){
		$return = ($value == $checkValue) ? 'selected':'';
		return $return;
	}	

	function checkedInput($value,$checkValue){
		$return = ($value == $checkValue) ? 'checked':'';
		return $return;
	}	
		
	function CheckEmail($email){
		
		$regex1 = '/^[_a-z0-9-][^()<>@,;:"[] ]*@([a-z0-9-]+.)+[a-z]{2,4}$/i'; 
		$regex2 = '/^([a-zA-Z0-9])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-]+)+/'; 
		$regex3 = '/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/';
		

		$email = strtolower($email);

		if (preg_match($regex3, $email))
		{
			$email = $email; 
		} 
		
		else { $email = false; } 
		
		return $email;

	}

	function printData($array){

		echo '<pre>'.print_r($array).'</pre>';

	}
	
	function generatePassword($length = 8){

			// start with a blank password
			$password = "";

			// define possible characters - any character in this string can be
			// picked for use in the password, so if you want to put vowels back in
			// or add special characters such as exclamation marks, this is where
			// you should do it
			$possible = "2346789bcdfghjkmnpqrtvwxyzBCDFGHJKLMNPQRTVWXYZ";

			// we refer to the length of $possible a few times, so let's grab it now
			$maxlength = strlen($possible);
		  
			// check for length overflow and truncate if necessary
			if ($length > $maxlength) {
			  $length = $maxlength;
			}
			
			// set up a counter for how many characters are in the password so far
			$i = 0; 
			
			// add random characters to $password until $length is reached
			while ($i < $length) { 

			  // pick a random character from the possible ones
			  $char = substr($possible, mt_rand(0, $maxlength-1), 1);
				
			  // have we already used this character in $password?
			  if (!strstr($password, $char)) { 
				// no, so it's OK to add it onto the end of whatever we've already got...
				$password .= $char;
				// ... and increase the counter by one
				$i++;
			  }

			}

			// done!
			return $password;

	}
	
	function callFeedback($id, $colorclass, $icon, $string){
			
		include('config.inc.php');
		// callfeedback($feedbackstring[0],$feedbackstring[1],$feedbackstring[2],$feedbackstring[3]);
		// $feedbackstring = array('succesbox2','greenNotebox','Accept24.png','<p>Update succesvol</p>');
		
		$return ='
		<div id="'.$id.'" class="notebox '.$colorclass.'">
			<table summary="error">
				<tr >
					<td  valign="top" style="padding-right:10px;"><img src="'.$cmsroot.'images/icons/'.$icon.'" alt="'.$icon.'"/></td>
					<td valign="top" >'.$string.'</td>
				</tr>
			</table>

		</div>';
	
	
		return $return;
	
	}
	
	function toAgo($time,$language,$tense=false)
	{
	   
	   //time lengths
	   $lengths = array("60","60","24","7","4.35","12","10");

	   //the current time in unix
	   $now = time();

	   //timeinput will be in normal date format. It needs to be converted
	   $time = strtotime($time);

	   // calculate the difference of time in secconds.
	   $difference = $now - $time;


	   //for loop deviding $difference each time it pases the loop
	   // $j in the loop will be used later on to decide the time string format
	   for($j = 0; $difference >= $lengths[$j] && $j < count($lengths)-1; $j++) {
	       $difference /= $lengths[$j];

	   }

	   // round the difference down or up 
	   $difference = round($difference);

	   //make new variable
	   $period='';


	   // time periods accoring to the language
	   if($language == "en"){

	       //time inputs
	       $periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");

	       // insert the correct spelling matched with the $difference of time
	       if($difference !=1){
	         $period = $periods[$j]."s";
	       }

	       // the tense that will be used
	       if($tense=="true"){
	         $tense = "ago";
	       }

	   }

	   elseif($language=="nl"){

	    // insert the correct spelling matched with the $difference of time
	      if($difference==1){
	        
	        switch($j):
	          case 0: $period = "seconde"; break;
	          case 1: $period = "minuut"; break;
	          case 2: $period = "uur"; break;
	          case 3: $period = "dag"; break;
	          case 4: $period = "week"; break;
	          case 5: $period = "maand"; break;
	          case 6: $period = "jaar"; break;
	          case 7: $period = "decenia"; break;
	          default:"tijd onbekend"; break;
	        endswitch;

	      }

	      else{

	        switch($j):
	          case 0: $period = "seconden"; break;
	          case 1: $period = "minuten"; break;
	          case 2: $period = "uren"; break;
	          case 3: $period = "dagen"; break;
	          case 4: $period = "weken"; break;
	          case 5: $period = "maanden"; break;
	          case 6: $period = "jaren"; break;
	          case 7: $period = "decenia"; break;
	          default:"tijd onbekend"; break;
	        endswitch;


	      }

	       // the tense that will be used
	       if($tense=="true"){
	         $tense = "geleden";
	       }

	   }//end if        

	   return "$difference $period $tense";

	}// end toAgo function

	function filePutImage($fullpath,$url){
		//-- date created: 06-02-2015
		if(file_put_contents($fullpath, file_get_contents($url))){
			return true;
		}
		else{ 
			return false;
		}

	}


	function get_ip()
	{
		/*
		| Als PHP gebruikt maakt van $_SERVER,
		| meerdere pogingen doen om het IP te achterhalen
		| en in $realip weg te schrijven.
		*/
		if(isset($_SERVER))
		{
			if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
			{
				$realip = $_SERVER['HTTP_X_FORWARDED_FOR'];
			}
			elseif(isset($_SERVER['HTTP_CLIENT_IP']))
			{
				$realip = $_SERVER['HTTP_CLIENT_IP'];
			}
			else
			{
				$realip = $_SERVER['REMOTE_ADDR'];
			}
		}
		
		/*
		| Als PHP geen gebruik maakt van $_SERVER 
		| moeten we wat anders proberen.
		*/
		else
		{
			if(getenv('HTTP_X_FORWARDED_FOR'))
			{
				$realip = getenv('HTTP_X_FORWARDED_FOR');
			}
			elseif(getenv('HTTP_CLIENT_IP'))
			{
				$realip = getenv('HTTP_CLIENT_IP');
			}
			else
			{
				$realip = getenv('REMOTE_ADDR');
			}
		}
		
		/*
		| De variabele realip returnen, zodat we die kunnen gebruiken
		*/
		return $realip;
	}


	function makeFilename($path,$ext){

		// $path: folder path including trailing /
		// $ext : file extention (eg. jpg, pdf ,etc.) without "."

		//if path does not contain trailing slash, add trailing slash
		$path = (substr($path, -1) != '/') ? $path.'/':$path;

		$filename = $this->generatePassword(12).'.'.$ext;

		$final_path = $path.$filename;


		// make a new filename and check if it exists in the folder
		// if it exitst in the folder, give it a new name untill it doesn't exist.
		if(file_exists($final_path)){
			$this->makeFilename($path,$ext);	
		}
		else{
			return $filename;
		}
		

	}
	
	function convertDate($date,$format){
		return date($format, strtotime($date));
	}

	function futureDate($var){
		return date('Y-m-d H:i:s', strtotime($var));	
	}

	function futureFromDate($var,$date){
		
		return date('Y-m-d H:i:s', strtotime($date.' '.$var));

		
	}

	function normalDate($string){ 
		//functie om mysql datetime format(2011-08-22 10:05:11) om te zetten naar een normale datum (01-08-2011)
		//$string = "2011-11-01 12:06:01";
		
		$string = substr($string, 0, 10);
		$string = explode("-",$string);
		$string = $string[2]."-".$string[1]."-".$string[0];
		return $string;
	}
	
	function makekeywords($string){ 
		
		$string = eregi_replace(" ", ",", $string);
	
		return $string;
	}
	
	
	function urlinsql($var){ 

		$var = urlencode($var);
		$var = stripslashes ($var);

		return $var;
	}
	
	function urloutsql($var) { 
		$var = urldecode($var);
		$var = stripslashes ($var);

		return $var; 
	}
	
	
	function deleteFile($file){
		
		if(file_exists($file)){
			
			unlink($file);
			return TRUE;
			
		}
		else{ return FALSE; }
	
	}
	
	
	function splitMoney($cents,$return){

		if(strlen($cents) < 3){
			$cents = '00'.$cents;
		}

		$length = strlen($cents);

		$money1 = substr($cents,0,$length-2);
		$money2 = substr($cents,-2,2);


		$arr = array($money1,$money2);

		if($return=='full'){
			return $arr['0'].','.$arr['1'];
		}

		if($return=='split'){
			return $arr;
		}

	}//end function splitMoney
	
	
	
	
	
	
	
/*------------image verklein/vergroot settings------------*/

function createPicture($filename, $tmpname){
	include('config.img.php');
	if(preg_match('/[.](jpg)|(JPEG)|(gif)|(png)$/', $filename)) {   
		
				$imageFile = $tmpname;
				$filename = mktime().basename($filename);
				$filename =  str_replace(' ', '_', $filename);
				
				list($width, $height) = getimagesize($imageFile);
				
				//$src = imagecreatefromjpeg($imageFile);
				if(preg_match('/[.](jpg)$/', $filename)) {
					$src = imagecreatefromjpeg($imageFile);   
				}	
				if(preg_match('/[.](jpeg)$/', $filename)) {   
					$src = imagecreatefromjpeg($imageFile);   
				}
					if(preg_match('/[.](JPG)$/', $filename)) {   
					$src = imagecreatefromjpeg($imageFile);   
				}
				if (preg_match('/[.](gif)$/', $filename)) {   
					$src = imagecreatefromgif($imageFile);   
				}
				if (preg_match('/[.](png)$/', $filename)) {   
					$src = imagecreatefrompng($imageFile);   
				}
				
				$orig_h = ($height/$width)* $orig_w;
				
				if($orig_h){
				
					$tmp = imagecreatetruecolor($orig_w, $orig_h);
					imagecopyresampled($tmp, $src, 0,0,0,0,$orig_w,$orig_h,$width,$height);
					imagejpeg($tmp, $folder.$filename,100);
					
					chmod($folder.$filename, 0755);
					
					imagedestroy($tmp);
					imagedestroy($src);
					
					$filename = urlencode($filename);
					
					return $filename;
				}
				else {
					return FALSE;
				}

	}

}

	function startTable($style){
	
		return '<table '.$style.'>';
		
	}


	function addTr($trStyle, $style,  $style2, $td1, $td2){
	
		return '
		
			<tr '.$trStyle.'>
				<td '.$style.'>'.$td1.'</td><td '.$style2.'>'.$td2.'</td>		
			</tr>

		';
		
	}

	function addTrColspan($count,$tdStyle, $td1){
	
		return '
		
			<tr>
				<td colspan="'.$count.'"  '.$tdStyle.'>'.$td1.'</td>	
			</tr>

		';
		
	}

	function endTable(){
	
		return '</table>';
		
	}

	function discount2($high,$low){

		$discount = round((($high-$low)/$high)*100);
		
		//$discount = round($low / $high * 100);

		if($discount <= 0 ){
			return false;
		}
		else{
			return $discount;
		}

	}
	
	function percentagePrice($percent,$price){

		return (float)($price - ($price * ($percent/100)));

	}

	function getIpadress()
	{
	  if (!empty($_SERVER['HTTP_CLIENT_IP']))
	  //check ip from share internet
	  {
	    $ip=$_SERVER['HTTP_CLIENT_IP'];
	  }
	  elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
	  //to check ip is pass from proxy
	  {
	    $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
	  }
	  else
	  {
	    $ip=$_SERVER['REMOTE_ADDR'];
	  }
	  return $ip;
	}


	function imageCopy($source,$path){
		//-- $source full path including file and extention. Example: ../some/path/image.jpg or url
		//-- $folder: path (including trailing slash). Example: "../images/folder/"
		$filename = pathinfo($source);
		$finaldest = $path.$filename['basename'];

		if(!copy($source,$finaldest)){
			$return = false;
		}
		else{
			$return = true;
		}

		return $return;

	}

	function upload($input_name, $folder="", $types="") {

        if($_FILES[$input_name]['name']){

            $file_title = $_FILES[$input_name]['name'];

            //Get file extension
            //$ext_arr = explode("\.",basename($file_title));
            //$ext = strtolower($ext_arr[count($ext_arr)-1]); //Get the last extension
            $ext = pathinfo($file_title, PATHINFO_EXTENSION);

            $replacements = array(" ", "(", ")");
            $file_title = str_replace($replacements,"", $file_title);

            //Not realy uniqe - but for all practical reasons, it is
            $uniqer = substr(md5(uniqid(rand(),1)),0,5);
            $file_name = $uniqer . '_' . $file_title;//Get Unique Name

            $all_types = explode(",",strtolower($types));
            if($types) {
                if(in_array($ext,$all_types));

                else {
                    $result = "'".$_FILES[$input_name]['name']."' is not a valid file. <br> the extentions allowerd are : $ext"; //Show error if any.
                    //return array('',$result);
                    //die ($result);
                    return false; // not a valid file
                }
            }

            //Where the file must be uploaded to
            if($folder){ $folder .= '/'; } //Add a '/' at the end of the folder
            $uploadfile = $folder . $file_name;

            $result = '';
            
            //Move the file from the stored location to the new location
            if (!move_uploaded_file($_FILES[$input_name]['tmp_name'], $uploadfile)) {
                
                $result = "Cannot upload the file '".$_FILES[$input_name]['name']."' - check max_upload_size"; //Show error if any.
                
                if(!file_exists($folder)) {
                    $result .= " : Folder don't exist.";
                } elseif(!is_writable($folder)) {
                    $result .= " : Folder not writable.";
                } 

                /*elseif(!is_writable($uploadfile)) {
                    $result .= " : File not writable.";
                }*/
                $file_name = '';
                return($result);
                //die($result);
                
            } 
            else {
                // file transfer succeded.. do the last check

                if(!$_FILES[$input_name]['size']) { //Check if the file is made
                    @unlink($uploadfile);//Delete the Empty file
                    $file_name = '';
                    $result = "Empty file found - please use a valid file."; //Show the error message

                    //die($result);
                    return $result;// empty file

                } 
                else {
                    chmod($uploadfile,0777);//Make it universally writable.
                }

                //die($file_title );
                return $file_name;//succes
            }

        }//end if
        else{

            //die('There was no image'.$uploadfile);
            //return r; //no image exists
           	return false; //no image exists
        }

    }//end upload function


    function exifFix($input_name, $image){

    	//check if exif data exist
		$exif = @exif_read_data($_FILES[$input_name]['tmp_name']);

		if(!empty($exif['Orientation'])) {

		    switch($exif['Orientation']) {
		        case 8:
		            $image = imagerotate($image,90,0);
		            break;
		        case 3:
		            $image = imagerotate($image,180,0);
		            break;
		        case 6:
		            $image = imagerotate($image,-90,0);
		            break;
		    }
		}//end rotate check

		return $image;
    }// end exifFix

    function upload2($input_name, $folder)
    {


    	// Check file size (max 5MB) 
		if ($_FILES[$input_name]['size'] > 5000000) {
			return false;
		}
		else
		{

	    	//turn string into image
			$image = imagecreatefromstring(file_get_contents($_FILES[$input_name]['tmp_name']));
			
			/*
			| Read Exif data and fix orientation
			*/
			$image = $this->exifFix($input_name,$image);

			/*
			| make filename
			*/
			$filename 	= pathinfo($_FILES[$input_name]['name'], PATHINFO_FILENAME);
	        $uniqer 	= substr(md5(uniqid(rand(),1)),0,5);
	        $file_name 	= $filename .'_'. $uniqer .'.jpeg';//Get Unique Name
	      
	        /*
	        | path of final image
	        */
	        $final_image = $folder.$file_name;

	        /*
	        | upload the images
	        */
			if(imagejpeg($image, $final_image))
			{
				// The file has been uploaded, do final checks
				// check if the file has an size. If not, return false
	            if(!filesize($final_image)) 
	            {
	            	//Delete the Empty file if the size is 0 or less.
	                @unlink($final_image); 
	                $result = "Empty file found - please use a valid file."; //Show the error message
	                print_r($result);
	               
	                return false;
	            } 
	            else
	            {
	            	// if the file has a file size, make it writable
	            	//Make it universally writable.
	                chmod($final_image,0777);
	            }

				return $file_name;

			}
			else
			{
	            $result = "Cannot upload the file '".$_FILES[$input_name]['name']."' - check max_upload_size"; //Show error if any.
	     
	            if(!file_exists($folder))
	            {
	                $result .= " : Folder don't exist.";
	            }
	            elseif(!is_writable($folder))
	            {
	                $result .= " : Folder not writable.";
	            } 

	            print_r($result);

	            return false;
			}

		} // end else

	} // end upload 2








    function createThumbnail2($image,$with,$hight='auto',$folder){




    }


    function moveFile($olddir,$newdir,$filename,$action,$returnaction){
    	
    	// -- $action: addextension || replace 
    	// -- $actionaction: boolean (true:false) || filename 

    	// destination 
    	//-- exalple: $olddir = "../this/is/a/folder/". Note the trailing slash
    	$olddest = $olddir.$filename;
    	$newdest = $newdir.$filename;


    	//check if file exists in new directory
    	if(file_exists ($newdir.$filename)){

    		//action types

    		if($action == 'addextention'){

    			$filename = $this->generatePassword().'_'.$filename;
    			$newfile = $newdir.'_'.$filename;
    			
    			if(rename($olddest,$newfile)){

	    			$fb_file = $filename;
	    			$fb_response = true;

    			}
    			else{
    				$fb_file = $filename;
    				$fb_response = false;
    			}
    		}
    		//replace the original file
    		elseif($action == 'replace'){
    			
    			if(rename($olddest,$newdest)){

	    			$fb_file = $filename;
	    			$fb_response = true;

    			}
    			else{
    				$fb_file = $filename;
    				$fb_response = false;
    			}
    		}
    	}
    	else{

    		//file does not exist in the new folder so we can move the file
    		 	if(rename($olddest,$newdest)){

	    			$fb_file = $filename;
	    			$fb_response = true;

    			}
    			else{
    				$fb_file = $filename;
    				$fb_response = false;
    			}

    	}

    	//
    	// Returnaction
    	//
    	
    	if($returnaction=='boolean'){

    		return $fb_response;

    	}
    	elseif($returnaction=='filename'){

    		return $fb_file;
    	}


    }


    function getSelectList($dbTable, $value, $firstOption='', $postVar, $name, $class='', $extra=''){

        $return = '';
        $return .= '<select id="'.$name.'" name="'.$name.'" class="'.$class.'" '.$extra.'>';
        
        //active selected option
        $active[$postVar] = 'selected="selected"';

        if($firstOption !=''){
        	$return .= '<option value="0">'.$firstOption.'</option>';
        }
        
        $q = mysql_query("SELECT id, $value FROM $dbTable ORDER BY id ASC") or die(mysql_error());
        
        while($row = mysql_fetch_array($q)){
            
            
            
            $return .= '<option value="'.$row['id'].'" '.$active[$row['id']].'>'.$row[$value].'</option>';
            
        }
                
        $return .= '</select>';
        
        //die($return);

        return $return;
    }//get select list


    function getPressList($postVar){
		
		$active[$postVar] = 'selected="selected"';

		$return='';
    	
    	$return .= '<select name="press" class="width-20">';
    	
    	for($i=0; $i<20; $i++){

    		
	    		if($i==0){
	    			$return .='<option '.$active[$i].' value="'.$i.'">n.v.t</option>';
	    		}else{
	    			$return .='<option '.$active[$i].' value="'.$i.'">'.$i.'</option>';
	    		}
	    	

    	}
    	
    	$return .= '</select>';
    	
    	return $return;

    }//get select list


	function makeSearchString($search,$field) {

	           $terms = explode(" ", trim($search));
	           $i=0;
	           $query = '';
	           foreach($terms as $key){

	                $i++;

	                if($i==1){

	                    $query .= "$field LIKE '%$key%'";

	                }else{

	                    $query .= " AND $field LIKE '%$key%'";

	                }

	           }
	           
	           return($query);

	}//end function



	function PDOsearchString($search,$field) {

	           $terms = explode(" ", trim($search));

	           $i=0;
	           $query = '';
	           foreach($terms as $key)
	           {

	                $i++;

	                if($i==1)
	                {
	                    $query .= "$field LIKE ?";
	                }
	                else
	                {
	                    $query .= " AND $field LIKE ?";
	                }
	           }
	           

	           $array = array();
	           foreach($terms as $key)
	           {
	                    array_push($array,"%$key%");
	           }

	    
	           $return = array($query,$array);

	           return($return);

	}//end function



	function createSalt() {

    	$salt = uniqid(mt_rand(), true);

	    return $salt;

	}// end createSalt();


	function cssDisplay($value){

		$display = ($value == 1) ? "block":"none";
		 return $display;
	}

	function cssDisplay2($value,$blockValue){

		$display = ($value == $blockValue) ? "block":"none";
		return $display;
	}	

	function styleDisplay($value){

		$display = ($value == 1 || $value == true) ? "block":"none";
		return "style='display:$display'";
	}

	function styleDisplay2($value,$blockValue){

		$display = ($value == $blockValue) ? "block":"none";
		return "style='display:$display'";
	}

	function sendMail($from, $from_name, $to, $subject, $body) {
	    // if insert is true, send mail to the user
	    //-- include php mailer script

	    require_once("../classes/class.phpmailer.php");

		//global $error;

		$mail = new PHPMailer();  // create a new object
		$mail->IsSMTP(); // enable SMTP
		$mail->SMTPDebug = 0;  // debugging: 1 = errors and messages, 2 = messages only
		$mail->SMTPAuth = true;  // authentication enabled
		$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
		$mail->Host = 'smtp.gmail.com';
		$mail->Port = 465; 
		$mail->Username = 'boekendeals@gmail.com';  
		$mail->Password = 'helpme2helpyou';
		$mail->CharSet     = 'UTF-8';
		$mail->ContentType = 'text/html; charset=utf-8\r\n';           
		$mail->SetFrom($from, $from_name);
		$mail->Subject = $subject;
		$mail->Body = $body;
		$mail->AddAddress($to);
		$mail->isHTML( TRUE );

		if(!$mail->Send()) {
			//$error = 'Mail error: '.$mail->ErrorInfo; 
			return false;
		} else {
			//$error = 'Message sent!';
			return true;
		}
	}


	function timeLeft($date){
		//Convert to date
		$date=strtotime($date);//Converted to a PHP date (a second count)

		//Calculate difference
		$diff = $date-time();//time returns current time in seconds
		$days = floor($diff/(60*60*24));//seconds/minute*minutes/hour*hours/day)
		$hours = round(($diff-$days*60*60*24)/(60*60));

		$days_spelling = ($days > 1 ) ? "dagen":"dag";
		$hours_spelling = ($hours > 1 ) ? "uren":"uur";
		
		//Report
		$array['days'] = $days;
		$array['hours'] = $hours;

		$array['text'] = "$days $days_spelling $hours $hours_spelling ";
		return $array;
	
	}


	function base64_to_jpeg( $base64_string, $string, $folder ){

		//do some checks

 		$filename_path = md5(time().uniqid()).".jpg"; 
 		$decoded = base64_decode($base64_string_img);
 		file_put_contents("uploads/".$filename_path, $decoded); 

	}


	function dumpArray($array)
	{
		echo 'Number of arrays:'.count($array).'<br>';
		echo "<pre>";
		var_dump($array);
		echo "</pre>";	
	}


}//end class
?>