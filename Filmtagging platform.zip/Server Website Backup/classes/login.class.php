<?php 

class login{

	/*
	| Database instance
	*/
	protected $db;


	public function __construct( $var = false )
  {
		$this->db = Core::dbConnect();
        
        if($_POST['action']=='login')
        {
            $this->login();
        }       
   
        if($_GET['action']=='logout')
        {
            $this->destroy_cookie();
        }    

	}


    function makecookie($id){
        $session_time = 24 * 86400;
        setcookie('annoweb', rand(0,2000).'-'.$id , time() + $session_time, "/");
        header('Location:'.ROOT);
        
    }

    function destroy_cookie(){
      $session_time = 24 * 86400;
      setcookie('annoweb', "" , time() - $session_time, "/");
      header("Location:".ROOT);
    }
    
     function check_login($redirect=false){
        if($_COOKIE['annoweb'] != '')
        {
            return true;
        }
        else{
            if($redirect==true){
               header('Location:'.ROOT.'/login/');
            }
            else{
              return false;
            }
          
        }
    }

  function get_user_id()
  {
    if($_COOKIE['annoweb'] != '')
    {
      $id = explode("-", $_COOKIE['annoweb']);
      return $id[1];
    }
    else{
      return false;
    }
  }


	function login()
  {
        
        $email = $_POST['email'];
        $password = $_POST['password'];

    		$query = $this->db->prepare("SELECT * FROM users WHERE email=? AND password=? LIMIT 1");
    		if ( $query->execute(array($email,$password)) )
            {
              //check if a user is found with email/password combination
              if( $query->rowCount() == 1)
              {
                $row = $query->fetch();

                if( !$this->makecookie( $row['id']) ) 
                {
                    echo 'The cookie could not be made';
                    print_r($query->errorInfo());
                }
                else
                {
                  return true;
                }
              }
              //if no row is found, throw error
              else
              {
                echo "login failed";
                return false;
              }

            }
            else{
                  echo "login failed";
                  return false;
            } 

    	}

}

$login = new login;

?>

