<?php 

$login->check_login(true);
$db->exec('SET CHARACTER SET utf8'); 

$user_id = $login->get_user_id();


//add additional files 
#$head['add_files'] = [['<style,script,custom>',"<file path>"]];

$query = $db->prepare("SELECT * FROM videos ORDER BY RAND() LIMIT 1");
$query->execute();
$rows = $query->fetch();

$query = $db->prepare("SELECT * FROM skills");
$query->execute();
$skills = $query->fetchAll();

$query = $db->prepare("SELECT * FROM users WHERE id = $user_id LIMIT 1");
$query->execute();
$user = $query->fetch();

$query = $db->prepare("SELECT DISTINCT(tag_text) FROM users_annotations ORDER BY tag_text");
$query->execute();
$annotations = $query->fetchAll();


/*$query = $db->prepare("SELECT * FROM projects");
$query->execute();
$rows = $query->fetchAll();*/

?>
