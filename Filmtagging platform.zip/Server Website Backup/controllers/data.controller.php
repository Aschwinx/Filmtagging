<?php 

$login->check_login(true);


$query = $db->prepare("SELECT * FROM users_annotations");
$query->execute();
$rows = $query->fetchAll();

$query = $db->prepare("SELECT * FROM skills");
$query->execute();
$skills = $query->fetchAll();

$query = $db->prepare("SELECT * FROM users");
$query->execute();
$users = $query->fetchAll();

?>