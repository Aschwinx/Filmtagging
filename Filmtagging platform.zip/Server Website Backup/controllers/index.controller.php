<?php 

//add metatags
$head['meta']['title'] = "The Title tag";
$head['meta']['description'] = "description";
$head['meta']['robots'] = "index, follow";

//add additional files 
#$head['add_files'] = [['<style,script,custom>',"<file path>"]];




?>