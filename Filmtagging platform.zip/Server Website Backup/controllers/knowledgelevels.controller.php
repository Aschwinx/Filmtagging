<?php 

$login->check_login(true);

$user_id = $login->get_user_id();
//add additional files 
#$head['add_files'] = [['<style,script,custom>',"<file path>"]];

$query = $db->prepare("SELECT * FROM skills");
$query->execute();
$rows = $query->fetchAll();

$query = $db->prepare("SELECT * FROM skills");
$query->execute();
$rows2 = $query->fetchAll();

$query = $db->prepare("SELECT * FROM users WHERE id=$user_id");
$query->execute();
$scores = $query->fetch();


?>