<?php 

//add metatags
$head['meta']['title'] = "Login";
$head['meta']['description'] = "Login to acces your profile";
$head['meta']['robots'] = "no-index, no-follow";


if($_COOKIE['annoweb'] != '')
{
   header('Location:'.ROOT);
}
               

?>