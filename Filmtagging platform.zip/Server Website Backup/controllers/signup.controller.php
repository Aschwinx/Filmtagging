<?php 



//add additional files 
#$head['add_files'] = [['<style,script,custom>',"<file path>"]];

$query = $db->prepare("SELECT * FROM videos ORDER BY RAND() LIMIT 1");
$query->execute();
$rows = $query->fetch();

$query = $db->prepare("SELECT * FROM skills");
$query->execute();
$skills = $query->fetchAll();

$query = $db->prepare("SELECT * FROM users WHERE id=$user_id");
$query->execute();
$scores = $query->fetch();


/*$query = $db->prepare("SELECT * FROM projects");
$query->execute();
$rows = $query->fetchAll();*/

?>
