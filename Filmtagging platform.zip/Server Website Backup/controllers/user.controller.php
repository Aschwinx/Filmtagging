<?php 

$login->check_login(true);

$query = $db->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
$query->execute(array($_GET['var']));
$user = $query->fetch();

$query = $db->prepare("SELECT * FROM users_annotations WHERE user_id = ?");
$query->execute(array($_GET['var']));
$rows = $query->fetchAll();


$query = $db->prepare("SELECT * FROM skills");
$query->execute();
$skills = $query->fetchAll();

?>