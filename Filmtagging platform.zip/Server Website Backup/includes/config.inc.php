<?php 

$root  = "http://astacia.eculture.labs.vu.nl";
define('ROOT', $root);

?>
