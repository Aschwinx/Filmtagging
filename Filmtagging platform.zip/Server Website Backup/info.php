<?php 
phpinfo();
?>