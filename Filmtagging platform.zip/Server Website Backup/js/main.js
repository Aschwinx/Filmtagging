$(document).ready(function(){

//alert('a');

$('.project_skills').select2({
	//tags: true
});

});


