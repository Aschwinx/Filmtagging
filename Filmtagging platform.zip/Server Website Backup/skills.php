
$query = $db->prepare("INSERT INTO skills (name) VALUES(:name)");

$file = fopen("skills.csv","r");

echo "<pre>";


while(($line = fgetcsv($file)) !== FALSE)
  {
  	//print_r($line);
  	$skill = trim($line[0]);

  	$query->bindValue(":name", $skill, PDO::PARAM_STR);
  	$query->execute();
  }

echo "finished";
echo "</pre>";


fclose($file);