
	<div class="container">
		<div class="row" style="margin-left: 5px">
			<footer class="footer-content">
			<div class="col-md-10" style="margin-top: 30px">
				<p>
					&copy; 2016 Filmtagging
				</p>
			</div>
			<div class="col-md-2" >
				<img src="<?php echo ROOT;?>/images/footer/vulogo.png" alt="NanoDesk" style="height: 50px;"/>
				</div>
			</footer>
		</div><!--// row-->
	</div><!--// container-->
