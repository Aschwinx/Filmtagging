<!-- <div class="site-container header-main">
			<header> -->

			<style>
				.navbar-inverse .navbar-nav> li > a{
					color: #404040;

				}
				.navbar-inverse .navbar-nav> li > a:hover{
					color: gray;
				}
				.navbar-inverse .navbar-toggle .icon-bar {
					background-color: black;
				}
				.navbar-inverse .navbar-toggle {
					background-color: white;
				}

			</style>

				<nav class="navbar navbar-inverse navbar-fixed-top" style="background-color: white;border-color: white;box-shadow: 0px 1px 2px #b1b1b1;">

  					<div class="navbar-header" style="display: inline-block;">
  					
						<a class="navbar-brand" href="<?php echo ROOT; ?>/index/"><img src="<?php echo ROOT;?>/images/logo4.svg" alt="NanoDesk" style="height: 30px"/></a>					
					</div>

<!-- 					<div class="navbar-brand" style="margin-top: 6px">
						<a href="<?php echo ROOT; ?>/index/" style="font-weight: bold;font-size: 30px;color: #1788e3">ANNOTATION</a>
					</div> -->
					
					<button class="navbar-toggle" data-toggle ="collapse" data-target=".navHeaderCollapse">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>

					<div class="collapse navbar-collapse navHeaderCollapse">


	
					<ul class="nav navbar-nav" style="margin-top: 6px">
						<li><a href="<?php echo ROOT; ?>/annotatefilm/">Annotate film</a></li>
                        <li><a   href="<?php echo ROOT; ?>/knowledgelevels/">Knowledge levels</a></li>
                        <li><a   href="<?php echo ROOT; ?>/data/">Data extraction</a></li>
                        

					</ul>

					<?php 
						if( $login->check_login() ):
					?>
						<ul class="nav navbar-nav navbar-right" style="margin-top: 6px;margin-right: 8px">
														<li><a href="<?php echo ROOT; ?>/user/<?php echo $login->get_user_id();?>"><?php 

							$user_id = $login->get_user_id();
							$query = $db->prepare("SELECT * FROM users WHERE id = $user_id ");
							$query->execute();
							$user2 = $query->fetch();

							echo $user2["userName"];

							?></a></li>
							<li><a href="<?php echo ROOT;?>/&action=logout/">Logout</a></li>
						</ul>


					<?php else: ?>
		

						<ul class="nav navbar-nav navbar-right" style="margin-top: 6px">
							<li><a href="<?php echo ROOT; ?>/signup/">Sign Up</a></li>
							<li><a href="<?php echo ROOT; ?>/login/">Log In</a></li>
							<li><a></a></li>
						</ul>
						<ul>
							
						</ul>
					<?php 
						endif;
					?>
				</div>
				</nav>			
<!-- 			</header>
</div>//site container -->
