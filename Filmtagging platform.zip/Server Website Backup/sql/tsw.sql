-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2016 at 12:14 PM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tsw`
--

-- --------------------------------------------------------

--
-- Table structure for table `faculties`
--

CREATE TABLE IF NOT EXISTS `faculties` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `logins`
--

CREATE TABLE IF NOT EXISTS `logins` (
  `uid` varchar(54) NOT NULL,
  `sid` varchar(54) NOT NULL,
  `ip` text NOT NULL,
  `datum` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logins`
--

INSERT INTO `logins` (`uid`, `sid`, `ip`, `datum`) VALUES
('1', 'bbe1e93dc29744462b9dbd9a866918fd', '::1', '2016-03-10 10:05:00'),
('1', '76dee7871b097da2c4a4c33e29ca6a4c', '::1', '2016-03-13 21:41:13');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `short_description` text NOT NULL,
  `img` text NOT NULL,
  `skills` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `date`, `user_id`, `title`, `description`, `short_description`, `img`, `skills`) VALUES
(1, '2016-03-13 22:20:37', 1, 'Project1', 'test5', '', '6ea0d_33_2560x1440.jpg', '22,24'),
(2, '2016-03-14 00:00:46', 1, 'Project 2', 'project desc2', '', '2cfa0_enkel1.jpg', '5,6,89'),
(3, '2016-03-14 00:22:05', 1, 'Project 3', 'desc 3', '', '74585_7d325b15f548bbc7346882cba92f32e6-jaw-droppingly-incredible-attack-on-titan-adventure-time-mashup.jpg', '76,90'),
(4, '2016-03-14 00:37:24', 1, 'Project 4', 'desc 4', '', '33afb_buddah.jpg', '5,21,43');

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE IF NOT EXISTS `skills` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `parent_id`, `name`) VALUES
(1, 0, '.Net'),
(2, 0, 'AngularJS'),
(3, 0, 'API'),
(4, 0, 'Assembly'),
(5, 0, 'C Sharp'),
(6, 0, 'C++'),
(7, 0, 'Cassandra'),
(8, 0, 'CSS'),
(9, 0, 'Erlang'),
(10, 0, 'Groovy'),
(11, 0, 'Hadoop'),
(12, 0, 'HTML'),
(13, 0, 'HTML5'),
(14, 0, 'Javascript'),
(15, 0, 'Laravel'),
(16, 0, 'Meteor JS'),
(17, 0, 'MongoDB'),
(18, 0, 'MySQL'),
(19, 0, 'Node JS'),
(20, 0, 'NoSQL'),
(21, 0, 'Oracle'),
(22, 0, 'PHP'),
(23, 0, 'Postgres'),
(24, 0, 'Python'),
(25, 0, 'Ruby'),
(26, 0, 'Ruby Rails'),
(27, 0, 'Sparql'),
(28, 0, 'SQL'),
(29, 0, 'UX'),
(30, 0, 'XML'),
(31, 0, 'iOS'),
(32, 0, 'Javascript'),
(33, 0, 'Meteor JS'),
(34, 0, 'Node JS'),
(35, 0, 'PHP'),
(36, 0, 'Testing'),
(37, 0, 'UI'),
(38, 0, 'UX'),
(39, 0, 'Xamaric'),
(40, 0, 'HTML5'),
(41, 0, 'Javascript'),
(42, 0, 'Laravel'),
(43, 0, 'Linked Data'),
(44, 0, 'MySQL'),
(45, 0, 'Node JS'),
(46, 0, 'NoSQL'),
(47, 0, 'Photoshop'),
(48, 0, 'PHP'),
(49, 0, 'Python'),
(50, 0, 'Ruby'),
(51, 0, 'Semantic Web'),
(52, 0, 'Semantics'),
(53, 0, 'Sparql'),
(54, 0, 'SQL'),
(55, 0, 'UI'),
(56, 0, 'UX'),
(57, 0, 'Wordpress'),
(58, 0, 'XML'),
(59, 0, 'RDF'),
(60, 0, 'OWL'),
(61, 0, 'Android'),
(62, 0, 'Back-end'),
(63, 0, 'C'),
(64, 0, 'C++'),
(65, 0, 'CSS'),
(66, 0, 'Front-end'),
(67, 0, '.Net'),
(68, 0, 'AngularJS'),
(69, 0, 'API'),
(70, 0, 'C'),
(71, 0, 'C++'),
(72, 0, 'CSS'),
(73, 0, 'Data'),
(74, 0, 'Data Analysis'),
(75, 0, 'Data Collection'),
(76, 0, 'Data Mining'),
(77, 0, 'Data Protection'),
(78, 0, 'Data Visualization'),
(79, 0, 'Decision Making'),
(80, 0, 'Deductive Reasoning'),
(81, 0, 'Evaluating'),
(82, 0, 'Mathematical'),
(83, 0, 'Models'),
(84, 0, 'Prioritization'),
(85, 0, 'Problem Solving'),
(86, 0, 'Qualitative Analysis'),
(87, 0, 'Quantitative Analysis'),
(88, 0, 'Reporting'),
(89, 0, 'Research'),
(90, 0, 'Social Media Analytics'),
(91, 0, 'Statistical'),
(92, 0, 'Surveying'),
(93, 0, 'Trends'),
(94, 0, 'Web Analytics'),
(95, 0, 'Analyzing'),
(96, 0, 'Auditing'),
(97, 0, 'Classifying'),
(98, 0, 'Comparing'),
(99, 0, 'Computing'),
(100, 0, 'Critical Thinking'),
(101, 0, '.Net'),
(102, 0, 'AngularJS'),
(103, 0, 'API'),
(104, 0, 'Assembly'),
(105, 0, 'C Sharp'),
(106, 0, 'C++'),
(107, 0, 'Cassandra'),
(108, 0, 'CSS'),
(109, 0, 'Erlang'),
(110, 0, 'Groovy'),
(111, 0, 'Hadoop'),
(112, 0, 'HTML'),
(113, 0, 'HTML5'),
(114, 0, 'Javascript'),
(115, 0, 'Laravel'),
(116, 0, 'Meteor JS'),
(117, 0, 'MongoDB'),
(118, 0, 'MySQL'),
(119, 0, 'Node JS'),
(120, 0, 'NoSQL'),
(121, 0, 'Oracle'),
(122, 0, 'PHP'),
(123, 0, 'Postgres'),
(124, 0, 'Python'),
(125, 0, 'Ruby'),
(126, 0, 'Ruby Rails'),
(127, 0, 'Sparql'),
(128, 0, 'SQL'),
(129, 0, 'UX'),
(130, 0, 'XML'),
(131, 0, 'iOS'),
(132, 0, 'Javascript'),
(133, 0, 'Meteor JS'),
(134, 0, 'Node JS'),
(135, 0, 'PHP'),
(136, 0, 'Testing'),
(137, 0, 'UI'),
(138, 0, 'UX'),
(139, 0, 'Xamaric'),
(140, 0, 'HTML5'),
(141, 0, 'Javascript'),
(142, 0, 'Laravel'),
(143, 0, 'Linked Data'),
(144, 0, 'MySQL'),
(145, 0, 'Node JS'),
(146, 0, 'NoSQL'),
(147, 0, 'Photoshop'),
(148, 0, 'PHP'),
(149, 0, 'Python'),
(150, 0, 'Ruby'),
(151, 0, 'Semantic Web'),
(152, 0, 'Semantics'),
(153, 0, 'Sparql'),
(154, 0, 'SQL'),
(155, 0, 'UI'),
(156, 0, 'UX'),
(157, 0, 'Wordpress'),
(158, 0, 'XML'),
(159, 0, 'RDF'),
(160, 0, 'OWL'),
(161, 0, 'Android'),
(162, 0, 'Back-end'),
(163, 0, 'C'),
(164, 0, 'C++'),
(165, 0, 'CSS'),
(166, 0, 'Front-end'),
(167, 0, '.Net'),
(168, 0, 'AngularJS'),
(169, 0, 'API'),
(170, 0, 'C'),
(171, 0, 'C++'),
(172, 0, 'CSS'),
(173, 0, 'Data'),
(174, 0, 'Data Analysis'),
(175, 0, 'Data Collection'),
(176, 0, 'Data Mining'),
(177, 0, 'Data Protection'),
(178, 0, 'Data Visualization'),
(179, 0, 'Decision Making'),
(180, 0, 'Deductive Reasoning'),
(181, 0, 'Evaluating'),
(182, 0, 'Mathematical'),
(183, 0, 'Models'),
(184, 0, 'Prioritization'),
(185, 0, 'Problem Solving'),
(186, 0, 'Qualitative Analysis'),
(187, 0, 'Quantitative Analysis'),
(188, 0, 'Reporting'),
(189, 0, 'Research'),
(190, 0, 'Social Media Analytics'),
(191, 0, 'Statistical'),
(192, 0, 'Surveying'),
(193, 0, 'Trends'),
(194, 0, 'Web Analytics'),
(195, 0, 'Analyzing'),
(196, 0, 'Auditing'),
(197, 0, 'Classifying'),
(198, 0, 'Comparing'),
(199, 0, 'Computing'),
(200, 0, 'Critical Thinking');

-- --------------------------------------------------------

--
-- Table structure for table `users2`
--

CREATE TABLE IF NOT EXISTS `users2` (
  `id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(54) NOT NULL,
  `username` varchar(255) NOT NULL,
  `skills` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users2`
--

INSERT INTO `users2` (`id`, `date`, `email`, `password`, `username`, `skills`) VALUES
(1, '2015-12-14 00:00:00', 'test@test.com', '4028a0e356acc947fcd2bfbf00cef11e128d484a', 'Ilias Elmzouri', '4,6,90,43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `faculties`
--
ALTER TABLE `faculties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users2`
--
ALTER TABLE `users2`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `faculties`
--
ALTER TABLE `faculties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=201;
--
-- AUTO_INCREMENT for table `users2`
--
ALTER TABLE `users2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
