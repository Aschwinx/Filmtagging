<?php 
	//insert this view
	include('snippets/header.php'); 
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  						<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$('#insert').click(function(event){
			event.preventDefault();
			$.ajax({
				url: "<?php echo ROOT?>/ajax/insert.php",
				method: "post",
				data: $('#myForm').serialize(),
				dataType: "text",
				success: function(strMessage){
					$('#message').text(strMessage);

					if ($.trim(strMessage) == "empty") {
						$('#insert').attr('value','Fill required fields')
						$('#insert').attr('class','btn btn-warning btn-block')
						setTimeout(reset, 1000)					

					}
					else if ($.trim(strMessage) == "error"){
						$('#insert').attr('value','error')
						$('#insert').attr('class','btn btn-danger btn-block')
						setTimeout(reset, 1000)

					}
					else if ($.trim(strMessage) == "success"){
						$('#insert').attr('value','Annotation submitted')
						$('#insert').attr('class','btn btn-success btn-block')
						setTimeout(reset, 1000);

						$("#tag-text").val("");
						$("#tag-description").val("");
						
						
					}	

					function reset(){
                   				$('#insert').attr('value','Submit annotation')
                   				$('#insert').attr('class','btn btn-primary btn-block')
                   			}					

				}
			})

		})
	})
</script>

<script>
	function hoverText1(s1){
	var s1	= document.getElementById(s1)
								
	if (s1.value == "Cinematography") {

	$('#hover1').attr('data-content','Cinematography is the art of motion-picture photography by recording light, either electronically, or chemically.')

	}     
	else if (s1.value == "Cultural History") {

	$('#hover1').attr('data-content','Cultural history is the study of cultural tradition, historical experiences and experiences of ordinary people in the past.')
	}  
	else if (s1.value == "Locations") {

	$('#hover1').attr('data-content','Locations focuses on the places scenes are recorded such as the city, street, or structure.')

	}
	else if (s1.value == "--Select a category--") {

	$('#hover1').attr('data-content','Select a category first to see info about the category.')

	}                       				
    }		

</script>


<script>
	function hoverText2(s2){
	var s2	= document.getElementById(s2)
								
	if (s2.value == "Lighting/Special effect") {
		$('#hover2').attr('data-content','(e.g. backlight, under lighting, fill light, key light, lens flare, soft light, stop motion, CGI, bullet time, green screen, practical effects, dolly zoom, etc.) ')

		} 
	else if (s2.value == "Camera technique") {

		$('#hover2').attr('data-content','(e.g. Camera Angle, Shot size, Camera movement, track, pan, zoom, tilt, crane, etc.)')

		}
	else if (s2.value == "Editing/Transition") {

		$('#hover2').attr('data-content','(e.g. cut, cross-cutting, continuity cuts, montage, jump cut, flashback, dissolve, wipe, etc.)')

		}    
	else if (s2.value == "Tradition and religion") {

		$('#hover2').attr('data-content',' (e.g. Christmas, new year, sinterklaas, Hanukkah, Judaism, Islam, Christianity, etc.) ')
		} 
	else if (s2.value == "Art") {

		$('#hover2').attr('data-content','(e.g. paintings, architecture, sculptures, dancing, theatre, music, etc.)')

		}      
	else if (s2.value == "Historical event") {

		$('#hover2').attr('data-content','(e.g. WWII, Chernobyl, Assassination of Abraham Lincoln, 9/11, Moon landing, etc.)')

		} 
	else if (s2.value == "Life-style/Practices") {

		$('#hover2').attr('data-content','(The way people lived their day lives, how they socialized and their jobs (e.g. rich, poor, minorities, majority, family, honesty, bisexual, heterosexual, homosexual, smoking, alcohol consumption, drugs, etc.)')
		}       
	else if (s2.value == "Social Structures") {

		$('#hover2').attr('data-content','(e.g. the relationship among minorities and the majority, a groups position/values, customs which represent how such a group would think and behave, Interaction among members of certain social groups/positions)')

		}
	else if (s2.value == "Country") {

		$('#hover2').attr('data-content','(e.g. Netherlands, America, United Kingdom, etc.)')
		}
	
	else if (s2.value == "City") {

		$('#hover2').attr('data-content','(e.g. Amsterdam, New York, Berlin, Moskou, Lelystad, etc.)')

		}
	else if (s2.value == "Street") {

		$('#hover2').attr('data-content','(e.g. Kalverstraat, P.C. Hooftstraat, Kinkerstraat, Broadway, etc.)')

		}
	else if (s2.value == "Structure") {

		$('#hover2').attr('data-content','(e.g. Rijksmuseum, Anne Frank House, Empire State Building, Brooklyn Bridge, etc.)')

		}
	else if (s2.value == "--Select a subcategory--") {

		$('#hover2').attr('data-content','Select a subcategory first to see info about the subcategory.')

		} 
	else if (s2.value == "--Select a category first--") {

		$('#hover2').attr('data-content','Select a subcategory first to see info about the subcategory.')

		}                          				
		}		
</script>
<script type="text/javascript">
	function changeFields(s1,s2,s3){
									
	var s1	= document.getElementById(s1)
	var s2	= document.getElementById(s2)
	var s3	= document.getElementById(s3)


	s2.innerHTML = "";
	s3.innerHTML = "";

	if(s1.value == "Cinematography"){
		var optionArray = ["--Select a subcategory--","Lighting/Special effect","Camera technique","Editing/Transition"]
		var optionArray2 = ["--Select a class--","Camera shot","Camera angle","Mise en Scene","Movement","Editing","Transition","Lighting","Special effect","Other"]
		$('#c-score').attr('value',<?php echo ($user["ls_score"]+$user["cm_score"]+$user["et_score"])/3?>)
		}
	else if (s1.value == "Cultural History"){
		var optionArray = ["--Select a subcategory--","Tradition and religion","Art","Historical event","Life-style/Practices","Social Structures"]
		var optionArray2 = ["--Select a class--","Place","Time","Person","Emotion","Object","Action","Visual art","Performing art","Tradition","Religion","Relationship","Norm","Desires","Interaction","Values","Sexual orientation","Habits","Engagement","Other"]
		$('#c-score').attr('value',<?php echo ($user["lp_score"]+$user["s_score"]+$user["tr_score"]+$user["a_score"]+$user["he_score"])/5?>)
		}
	else if (s1.value == "Locations"){
		var optionArray = ["--Select a subcategory--","Country","City","Street","Structure"]
		var optionArray2 = ["--Select a class--","Location","Building","Bridge","Other"]
		$('#c-score').attr('value',<?php echo ($user["co_score"]+$user["ci_score"]+$user["str_score"]+$user["st_score"])/4?>)
		}
	for(var option in optionArray){
		var pair = optionArray[option];
		var newOption = document.createElement("option");
		newOption.value = pair;										
		newOption.innerHTML = pair;
		s2.options.add(newOption)
		}
	for(var option in optionArray2){
		var pair = optionArray2[option];
		var newOption = document.createElement("option");
		newOption.value = pair;										
		newOption.innerHTML = pair;
		s3.options.add(newOption)
		}
	}

</script>

<script type="text/javascript">
	function startTime(){
		var vid = document.getElementById("vid");

    	var curmins = Math.floor(vid.currentTime / 60);
    	var cursecs = Math.floor(vid.currentTime - curmins * 60);

    	if(cursecs < 10){
    		cursecs = "0"+cursecs;
    		}

    	$('#start-time').attr('value',curmins+':'+cursecs);
	}

</script>

<script type="text/javascript">
	function endTime(){
		var vid = document.getElementById("vid");

    	var curmins = Math.floor(vid.currentTime / 60);
    	var cursecs = Math.floor(vid.currentTime - curmins * 60);

    	if(cursecs < 10){
    		cursecs = "0"+cursecs;
    		}
    		
    	$('#end-time').attr('value',curmins+':'+cursecs);
	}

</script>

<datalist id="suggestions">

    	<?php  
		foreach ($annotations as $value) {
		echo "<option>".$value["tag_text"]."</option>";
		}
	?>		
	<option value="A&B Rolls">
	<option value="Academy Aperture">
	<option value="Academy Leader ">
	<option value="Aerial shot">
	<option value="A.D.R">
	<option value="Anamorphic">
	<option value="Angle on">
	<option value="A-Wind">
	<option value="B-Wind">
	<option value="Backwind">
	<option value="Backlight">
	<option value="Balance Stripe">
	<option value="Best Light">
	<option value="Camera Noise">
	<option value="Cut">
	<option value="Cutaway">
	<option value="Close-up">
	<option value="Crawl">
	<option value="Cross-cut">
	<option value="Crossfade">
	<option value="Depth of Field">
	<option value="Diffusion">
	<option value="Dissolve">
	<option value="Dolly Shot">
	<option value="Double Exposure">
	<option value="Double Perf">
	<option value="Dutch Tilt">
	<option value="Edge Fog">
	<option value="Establishing shot">
	<option value="Eye Line">
	<option value="Fade">
	<option value="Favor">
	<option value="Flare">
	<option value="Flash Frame">
	<option value="Flashback">
	<option value="Freeze frame">
	<option value="Frontal lighting">
	<option value="Fog">
	<option value="Follow Focus">
	<option value="Insert Shot">
	<option value="Intercut">
	<option value="Jump Cut">
	<option value="Lap dissolve">
	<option value="Lens Flare">
	<option value="Long shot">
	<option value="Low-key illumination">
	<option value="Master Shot">
	<option value="Matte Shot">
	<option value="Pan">
	<option value="Parallel Editing">
	<option value="P.O.V.">
	<option value="Push in">
	<option value="Rack Focus">
	<option value="Reaction Shot">
	<option value="Reverse Shot">
	<option value="Sidelight">
	<option value="Stock shot">
	<option value="Tilt">
	<option value="Time Lapse">
	<option value="Top lighting">
	<option value="Tracking Shot">
	<option value="Underlighting">
	<option value="Wide Lens">
	<option value="Zero Cut">
	<option value="Zoom">
</datalist>





<div class="site-container site-main" style="margin-top: 50px;background-color: #f9f9f9">
	<div class="container">
	<div class='row'>

		<div class="col-md-9" >
		<style type="text/css">
			h1 
			{	
				font-size: 30px;
			}

			h2 
			{	
				font-size: 20px;
				color: gray;
			}


		label{
				font-size: 15px;

			}
			b{
				font-size: 14px;
				color: gray;
				font-weight: lighter;
			}

		</style>

				<div class="row">

				
				<div class="col-md-12">

				<video class="hidden-xs" id="vid" width="100%" height="500" style="margin-bottom: 10px" controls>
   					<source src="<?php echo $rows["source"]?>">" type="video/mp4">
   					<source src="movie.ogg" type="video/ogg">
 					Your browser does not support the video tag.
				</video>
				<video class="visible-xs" id="vid" width="100%" height="300" style="margin-bottom: 10px" controls>
   					<source src="<?php echo $rows["source"]?>">" type="video/mp4">
   					<source src="movie.ogg" type="video/ogg">
 					Your browser does not support the video tag.
				</video>

				<div style="margin-left: 10px">
				<?php echo "<h1>".$rows["title"]."</h1>"."<h2>".$rows["director"]."</h2>".$rows["description"];?>
				</div>

				
				<br>

				<div class="col-md-12" style="margin-bottom: 20px">
				<div class="col-md-3">
				<label>Country:<?php echo " "."<b>".$rows["country"]."</b>";  ?></label><br><br>
				
				</div>
				<div class="col-md-3">
				<label>Producer:<?php echo " "."<b>".$rows["producer"]."</b>";  ?> </label><br><br>
				
				</div>
				<div class="col-md-3">
				<label>Year:<?php echo " "."<b>".$rows["year"]."</b>";  ?> </label><br>
				
				</div>
				<div class="col-md-3">
				<label>Language:<?php echo " "."<b>".$rows["language"]."</b>";  ?></label>
				
				</div>
				</div>


				<script>
				function refreshFunction() {
					location.reload();
					}
				</script>
				
				
				<div class="col-md-12">
				<button onclick="refreshFunction()" type="button" class="btn btn-primary btn-block " style="font-weight: bold;">Next</button>
				</div>

				</div>
				</div>

		</div>


<div class="col-md-3">
			<div class="panel panel-default">
				 <div class="panel-heading">Annotation form</div>
				<div class="panel-body">
					<form id="myForm" method="post">
						<div class="form-group">
							<label for="c-field" style="font-size: 15px;margin-right: 130px">Category<font color="red">*</font></label>
							
							<a id="hover1" name="hover1" href="#" data-toggle="popover" onclick="hoverText1('c-field')" data-placement="bottom" data-content="">info</a>

							<select id="c-field" type="text" name="c-field" class="form-control" onchange="changeFields(this.id,'sc-field','class-field')" >
								<option>--Select a category--</option>
								<?php  
								foreach ($skills as $value) {
									if ($value["parent_id"] == NULL) {
										echo "<option>".$value["name"]."</option>";}

									}
								?>							

							</select>
							
						</div> 
						<div class="form-group">
							<label for="sc-field" style="font-size: 15px;margin-right: 105px">Subcategory<font color="red">*</font></label>	

							<a id="hover2" name="hover2" href="#" data-toggle="popover" onclick="hoverText2('sc-field')" data-placement="bottom" data-content="">info</a>

							<select id="sc-field" type="text" name="sc-field" class="form-control" >
							<option>--Select a category first--</option>
							</select>
							
						</div>

						<div class="form-group">
							<label for="class-field" style="font-size: 15px">Classification<font color="red">*</font></label>							
							<select id="class-field" type="text" name="class-field" class="form-control">
							<option>--Select a category first--</option>
							</select>
							
						</div>



						<script>
						$(document).ready(function(){

						    $('[data-toggle="popover"]').popover();   
						});
						</script>
						
                        <label for="tag-text" style="font-size: 15px;"><a href="#" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Here write a tag of something you saw in the film that is related to the three categories above (suggestions are provided from tags of other users)">Tag:<font color="red">*</font></a></label>
                        <input type="text" list="suggestions" class="form-control" rows="3" style="margin-bottom: 10px" name="tag-text" id="tag-text"></input>

                        

                        <label for="tag-description" style="font-size: 15px;"><a href="#" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Here you can write a description of the tag provided above, this can be done if you think a tag of 2 or 3 words is not sufficient to explain what was perceived in the film">Tag description:</a></label>
                        <textarea type="text" class="form-control" rows="3" style="margin-bottom: 10px" name="tag-description" id="tag-description"></textarea>

                        

                        <div class="col-sm-6">
                        <label for="start-time" style="font-size: 15px"><a href="#" id="getTime" onclick="startTime()">Start time:</a></label>
                        <input  class="form-control" style="text-align: center;"  placeholder="00:00" name="start-time" id="start-time"></input>
                        </div>

                        <div class="col-sm-6" style="margin-bottom: 27px">
                        <label for="end-time" style="font-size: 15px" ><a href="#" id="getTime" onclick="endTime()">End time:</a></label>
                        <input type="text" style="text-align: center;"  class="form-control" rows="1" placeholder="00:00" name="end-time" id="end-time"></input>

                        </div>

                        <input type="text" name="movie-title" id="movie-title" hidden="true" value="<?php echo $rows['title']?>"></input>
                        <input type="text" name="movie-id" id="movie-id" hidden="true" value="<?php echo $rows['id']?>"></input>
                        <input type="text" name="c-score" id="c-score" hidden="true"  value=""></input>

                        <input type="submit" value="Submit annotation" name="insert" id="insert" class="btn btn-primary btn-block"></input>


					</form>

				</div>
			</div>
		</div>		

		</div><!--//row-->
	</div>
</div><!--//site container-->

<?php include('snippets/footer.php');  ?>
