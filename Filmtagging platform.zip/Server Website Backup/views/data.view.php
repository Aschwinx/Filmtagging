<?php 


	//insert this view
	include('snippets/header.php'); 
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$('#insert').click(function(event)
		{
			event.preventDefault();
			$.ajax({
				url: "<?php echo ROOT?>/ajax/data.php",
				method: "post",
				data: $('#myForm').serialize(),
				dataType: "text",
				success: function(strMessage){
					$('#data_output').html(strMessage)
	

				}
			})

		})
	})
</script>

<script type="text/javascript">
			function fnExcelReport() {
    		var tab_text = '<html xmlns:x="urn:schemas-microsoft-com:office:excel">';
    		tab_text = tab_text + '<head><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>';

    		tab_text = tab_text + '<x:Name>Annotations</x:Name>';

    		tab_text = tab_text + '<x:WorksheetOptions><x:Panes></x:Panes></x:WorksheetOptions></x:ExcelWorksheet>';
    		tab_text = tab_text + '</x:ExcelWorksheets></x:ExcelWorkbook></xml></head><body>';

    		tab_text = tab_text + "<table border='1px'>";
    		tab_text = tab_text + $('#data_output').html();
		    tab_text = tab_text + '</table></body></html>';

		    var data_type = 'data:application/vnd.ms-excel';
		    
		    var ua = window.navigator.userAgent;
		    var msie = ua.indexOf("MSIE ");
		    
		    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
		        if (window.navigator.msSaveBlob) {
		            var blob = new Blob([tab_text], {
		                type: "application/csv;charset=utf-8;"
		            });
		            navigator.msSaveBlob(blob, 'Annotation_metadata.xls');
		        }
		    } else {
		        $('#downloadButton').attr('href', data_type + ', ' + encodeURIComponent(tab_text));
		        $('#downloadButton').attr('download', 'Annotation_metadata.xls');
		    }

			}


</script>

<script type="text/javascript">
	function abcd(s1,s2,s3){
									
		var s1	= document.getElementById(s1)
		var s2	= document.getElementById(s2)
		var s3	= document.getElementById(s3)


		s2.innerHTML = "";
		s3.innerHTML = "";

		if(s1.value == "Cinematography"){
			var optionArray = ["-- All --","Lighting/Special effect","Camera technique","Editing/Transition"]
			var optionArray2 = ["-- All --","Camera shot","Camera angle","Mise en Scene","Movement","Editing","Transition","Lighting","Special effect","Other"]
			}
		else if (s1.value == "Cultural History"){
			var optionArray = ["-- All --","Tradition and religion","Art","Historical event","Life-style/Practices","Social Structures"]
			var optionArray2 = ["-- All --","Place","Time","Person","Emotion","Object","Action","Relationship","Norm","Desires","Interaction","Values","Sexual orientation","Habits","Engagement","Other"]
			}
		else if (s1.value == "Locations"){
			var optionArray = ["-- All --","Country","City","Street","Structure"]
			var optionArray2 = ["-- All --","Location","Building","Bridge","Other"]
			}
		else if (s1.value == "-- All --"){
			var optionArray = ["--Select a category first--"]
			var optionArray2 = ["--Select a category first--"]
			}
									
		for(var option in optionArray){
			var pair = optionArray[option];
			var newOption = document.createElement("option");
			newOption.value = pair;										
			newOption.innerHTML = pair;
			s2.options.add(newOption)
			}
		for(var option in optionArray2){
			var pair = optionArray2[option];
			var newOption = document.createElement("option");
			newOption.value = pair;										
			newOption.innerHTML = pair;
			s3.options.add(newOption)
			}
		}

</script><script type="text/javascript">
	function abcd(s1,s2,s3){
									
		var s1	= document.getElementById(s1)
		var s2	= document.getElementById(s2)
		var s3	= document.getElementById(s3)


		s2.innerHTML = "";
		s3.innerHTML = "";

		if(s1.value == "Cinematography"){
			var optionArray = ["-- All --","Lighting/Special effect","Camera technique","Editing/Transition"]
			var optionArray2 = ["-- All --","Camera shot","Camera angle","Mise en Scene","Movement","Editing","Transition","Lighting","Special effect","Other"]
			}
		else if (s1.value == "Cultural History"){
			var optionArray = ["-- All --","Tradition and religion","Art","Historical event","Life-style/Practices","Social Structures"]
			var optionArray2 = ["-- All --","Place","Time","Person","Emotion","Object","Action","Relationship","Norm","Desires","Interaction","Values","Sexual orientation","Habits","Engagement","Other"]
			}
		else if (s1.value == "Locations"){
			var optionArray = ["-- All --","Country","City","Street","Structure"]
			var optionArray2 = ["-- All --","Location","Building","Bridge","Other"]
			}
		else if (s1.value == "-- All --"){
			var optionArray = ["--Select a category first--"]
			var optionArray2 = ["--Select a category first--"]
			}
									
		for(var option in optionArray){
			var pair = optionArray[option];
			var newOption = document.createElement("option");
			newOption.value = pair;										
			newOption.innerHTML = pair;
			s2.options.add(newOption)
			}
		for(var option in optionArray2){
			var pair = optionArray2[option];
			var newOption = document.createElement("option");
			newOption.value = pair;										
			newOption.innerHTML = pair;
			s3.options.add(newOption)
			}
		}

</script><script type="text/javascript">
	function abcd(s1,s2,s3){
									
		var s1	= document.getElementById(s1)
		var s2	= document.getElementById(s2)
		var s3	= document.getElementById(s3)


		s2.innerHTML = "";
		s3.innerHTML = "";

		if(s1.value == "Cinematography"){
			var optionArray = ["-- All --","Lighting/Special effect","Camera technique","Editing/Transition"]
			var optionArray2 = ["-- All --","Camera shot","Camera angle","Mise en Scene","Movement","Editing","Transition","Lighting","Special effect","Other"]
			}
		else if (s1.value == "Cultural History"){
			var optionArray = ["-- All --","Tradition and religion","Art","Historical event","Life-style/Practices","Social Structures"]
			var optionArray2 = ["-- All --","Place","Time","Person","Emotion","Object","Action","Relationship","Norm","Desires","Interaction","Values","Sexual orientation","Habits","Engagement","Other"]
			}
		else if (s1.value == "Locations"){
			var optionArray = ["-- All --","Country","City","Street","Structure"]
			var optionArray2 = ["-- All --","Location","Building","Bridge","Other"]
			}
		else if (s1.value == "-- All --"){
			var optionArray = ["--Select a category first--"]
			var optionArray2 = ["--Select a category first--"]
			}
									
		for(var option in optionArray){
			var pair = optionArray[option];
			var newOption = document.createElement("option");
			newOption.value = pair;										
			newOption.innerHTML = pair;
			s2.options.add(newOption)
			}
		for(var option in optionArray2){
			var pair = optionArray2[option];
			var newOption = document.createElement("option");
			newOption.value = pair;										
			newOption.innerHTML = pair;
			s3.options.add(newOption)
			}
		}

</script>

<script type="text/javascript"> 
		function hideTable(){
		document.getElementById("data_output").style.display = "none";

			
		}


</script>

<script type="text/javascript"> 
	function showDownload(){
	document.getElementById("downloadButton").style.display = "block";			
	}


</script>


<style type="text/css">
				h1 
				{	
					font-size: 30px;
				}

				h2 
				{	
					font-size: 20px;
					color: gray;
				}


				label{
					font-size: 15px;

				}
				b{
					font-size: 14px;
					color: gray;
					font-weight: lighter;
				}

			</style>

<div class="site-container site-main" style="margin-top: 50px;background-color: #f9f9f9;min-height: 650px">
	<div class="container">
	<div class='row'>

		<div class="col-md-3">
			<div class="panel panel-default">
				 <div class="panel-heading">Filter</div>
				<div class="panel-body">
					<form id="myForm" method="post">
						
						<div class="form-group">
							<label for="c-field" style="font-size: 15px">Category</label>
							<select id="c-field" type="text" name="c-field" class="form-control" onchange="abcd(this.id,'sc-field','class-field')">
								<option>-- All --</option>

								<?php  
								foreach ($skills as $value) {
									if ($value["parent_id"] == NULL) {
										echo "<option>".$value["name"]."</option>";}
									}
								?>							

							</select>
						</div>
						<div class="form-group">
							<label for="sc-field" style="font-size: 15px">Subcategory</label>							
							<select id="sc-field" type="text" name="sc-field" class="form-control">
							<option>--Select a category first--</option>
							</select>
							
						</div>
						
						<div class="form-group">
							<label for="class-field" style="font-size: 15px">Classification</label>							
							<select id="class-field" type="text" name="class-field" class="form-control">
							<option>--Select a category first--</option>
							</select>
							
						</div>                       
						
						<div class="form-group">
							<label for="score-field" style="font-size: 15px">Score</label>							
							<select id="score-field" type="text" name="score-field" class="form-control">
							<option>-- All --</option>
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
							</select>
							
						</div>    	
                        <input value="Search" type="submit" name="insert" id="insert" onclick="showDownload()" class="btn btn-primary btn-block"></input>

                        <div align="right" style="margin-top: 5px">
                        <a href="#" id="downloadButton" style="display: none" align="right" onClick="javascript:fnExcelReport();">download</a>
                        </div>

					</form>

				</div>
			</div>
		</div>




		<div class="col-md-9" >
		
			<table id="data_output" class="table table-bordered table-hover table-condensed" style="background-color: white">
						
			</table>	

			<p id="abc" name="abc"></p>

			<div class='col-md-9'>

			
			<p id="message2"></p>
			
				
			
			</div>

		</div>

		

		</div><!--//row-->
	</div>
</div><!--//site container-->

<?php include('snippets/footer.php');  ?>
