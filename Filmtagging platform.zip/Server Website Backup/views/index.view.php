<?php 
	//insert this view
	include('snippets/header2.php'); 
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>


<div class="image">
<img class="visible-xs" src="<?php echo ROOT;?>/images/index/Image2.jpg" style="position: relative;height: 300px;);" alt="NanoDesk">
<img class="hidden-xs" src="<?php echo ROOT;?>/images/index/Image2.jpg" style="position: relative;width: 100%;);" alt="NanoDesk">

<h2 class="hidden-xs" style="position: absolute;top: 200px;width: 100%;color: white; font-size: 70px;"><center>Welcome</center></h2>
<h2 class="visible-xs" style="position: absolute;top: 100px;width: 100%;color: white; font-size: 50px;"><center>Welcome</center></h2>
<a  href="<?php echo ROOT; ?>/annotatefilm/" style="position: absolute;top: 330px;left: 50%;margin: 0px -100px;background-color: transparent;font-size: 18px;border-color: white" class="btn btn-primary">Start annotating now</a>
<a class="visible-xs" href="<?php echo ROOT; ?>/annotatefilm/" style="position: absolute;top: 180px;left: 50%;margin: 0px -100px;background-color: transparent;font-size: 18px;border-color: white;color: white" class="btn btn-primary">Start annotating now</a>
</div>


<div class="site-container site-main" style="background-color: white">
	<div class="container">
	<div class='row'>
	<div class="col-md-1">
	</div>
	<div class="col-md-9">
<p style="margin-left: 10px; margin-right: 10px">

Filmtagging is a crowdsourced tag collection platform in which tags are gathered over a wide variety of films between 1900-1960. Film experts are able to export the tags to use for various research activities. The goal of the platform is to collect as many tags as possible, which are related to three specific categories: 
</p>

<ul style="padding-left: 3em">
	<li>Cinematography: The art of motion-picture photography by recording light, either electronically or chemically.</li>
		<ul style="padding-left: 1em">
		<li>Camera techniques</li>
		<li>Editing/Transitions</li>
		<li>Lighting/Special effects</li>
		</ul>
</ul>

<ul style="padding-left: 3em">
	<li>Cultural History: The study of cultural tradition, historical experiences and experiences of ordinary people in the past</li>
	<ul style="padding-left: 1em">
		<li>Tradition and religion</li>
		<li>Art</li>
		<li>Historical events</li>
		<li>Life-style/Practices</li>
		<li>Social structures</li>
	</ul>
</ul>

<ul style="padding-left: 3em">
	<li>Locations: Focuses on the places film scenes are recorded such as a city, a street, a building, or a bridge.</li>
	<ul style="padding-left: 1em">
		<li>Country</li>
		<li>City</li>
		<li>Street</li>
		<li>Structure</li>
	</ul>
</ul>

<p style="margin-left: 10px; margin-right: 10px;font-size: 20px;font-weight: bold;">
How to participate?
</p>

<ol type="1" style="padding-left: 3em">
<li>Create an account via the <a  href="<?php echo ROOT; ?>/signup/">Sign Up</a> page</li>
<li>Login with your new account!</li>
<li>Go to the <a  href="<?php echo ROOT; ?>/annotatefilm/">"Annotate film"</a> page</li>
<li>Watch one randomly picked film from the 228 films on the platform</li>
<li>Place tags about what you see during or after watching the film in the "Annotation Form" which is located on the right side of the video.</li>
<ul style="padding-left: 1em">
	<li>Select the specific category of the tag you want to create (press the info button after selecting a category to get a description)</li>
	<li>Select the specific subcategory of the tag you want to create (press the info button after slecting a subcategory to get a description)</li>
	<li>Classify the tag you want to create</li>
	<li>Write the tag (autosuggestions are provided for various cinematographic terms)</li>
	<li>Give a description if needed</li>
	<li>Provide a timestamp to highlight at what time the tag appeared in the film, and when it ended</li>
	<li>Press submit to upload the tag to the platform</li>
</ul>	
<li>Continue watching the film and place more tags, or click “Next” underneath the film to move to the next film</li>
</ol>

<p style="margin-left: 10px; margin-right: 10px">
Watch as many films as you like, if you don’t find a film interesting feel free to skip the film and go to the next. <br><br>Here is a video showing the process of creating a account and adding some tags:
</p>

<video id="vid" width="100%" style="margin-bottom: 10px;margin-left: 10px" controls>
   	<source src="<?php echo ROOT; ?>/videos/process.mp4">" type="video/mp4">
   	<source src="movie.ogg" type="video/ogg">
 	Your browser does not support the video tag.
</video>

</div>

</div>
</div>
</div>

<?php include('snippets/footer.php');  ?>

