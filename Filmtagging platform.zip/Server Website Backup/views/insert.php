<?php  
	print_r($_POST['annotation-text']);


?>