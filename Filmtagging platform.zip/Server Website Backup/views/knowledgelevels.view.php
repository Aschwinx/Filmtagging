<?php 
	//insert this view
	include('snippets/header.php'); 
	

?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$('#insert').click(function(event){
			event.preventDefault();
			$.ajax({
				url: "<?php echo ROOT?>/ajax/insert2.php",
				method: "post",
				data: $('#myForm').serialize(),
				dataType: "text",
				success: function(strMessage){
					$('#message').text(strMessage)
					if ($.trim(strMessage) == "error"){
						$('#insert').attr('value','No changes submitted')
						$('#insert').attr('class','btn btn-warning btn-block')
						setTimeout(reset, 1000)

					}
					else if ($.trim(strMessage) == "success"){
						$('#insert').attr('value','Scores submitted')
						$('#insert').attr('class','btn btn-success btn-block')
						setTimeout(reset, 1000)

					}

					function reset(){
                   				$('#insert').attr('value','Submit scores')
                   				$('#insert').attr('class','btn btn-primary btn-block')
                   			}


					

				}
			})
		})
	})
</script>





<div class="site-container site-main" style="margin-top: 50px;background-color: #f9f9f9">
	<div class="container">
	<div class='row'>
	
		<div class="col-md-12" >
		<style type="text/css">
			h1 
			{	
			font-size: 20px;
			}

			h2 
			{	
			font-size: 16px;
			color: gray;
			}
			a
			{
			color: gray;
			}
		</style>


				<div class="row">
				<div class="col-sm-8" style="margin-left: 15px;margin-top: 10px">
				<h1 style="font-size: 30px; color: #404040;font-weight: bold;">
				Knowledge levels
				</h1>
				<p>	
				Submit your knowledge on a scale from 1 to 5 (1: No knowledge, 2: Little knowledge,<br> 3: General understanding, 4: Good understanding, 5: Expert).
				</p>
				<br>
				</div>



<!--  				<?php  

				foreach ($rows as $value) 
					{
						if ($value["parent_id"] == NULL) {
							echo "<h1>".$value["name"]."</h1>";	
							
						}

						foreach ($rows2 as $value2) {
							if ($value2["parent_id"] == $value["id"]) {
							echo "<h2>".$value2["name"]."</h2>"."<input id='rangeinput' type='range' min='1' max='5' value='3' style='width:400px' onchange='rangevalue.value=value'>";
								}



							}
						}
				?> -->				


<div class="col-sm-5" style="margin-left: 15px">

					<script>
						$(document).ready(function(){

						    $('[data-toggle="popover"]').popover();   
						});
						</script>

				<form id="myForm" method="post">
				<h1><a href="#" style="color: black; font-size: 20px" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="Cinematography is the art of motion-picture photography by recording light, either electronically, or chemically.">
				Cinematography
				</a></h1>
				<div style="display: inline-block;">
				<h2><a href="#" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. backlight, under lighting, fill light, key light, lens flare, soft light, stop motion, CGI, bullet time, green screen, practical effects, dolly zoom, etc.">
				Lighting/Special effect techniques
				</a></h2>	
				
				<input id="rangeinput" type="range" min="1" max="5" value="<?php echo $scores['ls_score'];?>" style="width: 320px" onchange="rangevalue1.value=value"/>	
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<h2>value</h2>
				<input type="text" id="rangevalue1" name="rangevalue1" value="<?php echo $scores['ls_score'];?>" style="width: 50px">		
				</div>

				<br>
				<div style="display: inline-block;">
				<h2><a href="#" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. Camera Angle, Shot size, Camera movement, track, pan, zoom, tilt, crane, etc.">
				Camera movement techniques
				</a></h2>				

				<input id="rangeinput" type="range" min="1" max="5" value="<?php echo $scores['cm_score'];?>" style="width: 320px" onchange="rangevalue2.value=value">
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<h2>value</h2>
				<input type="text" id="rangevalue2" name="rangevalue2" value="<?php echo $scores['cm_score'];?>" style="width: 50px">
				</div>
				<br>

				<div style="display: inline-block;">
				<h2><a href="#" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. cut, cross-cutting, continuity cuts, montage, jump cut, flashback, dissolve, wipe, etc.">
				Editing/Transition techniques
				</a></h2>			

				<input id="rangeinput" type="range" min="1" max="5" value="<?php echo $scores['et_score'];?>" style="width: 320px" onchange="rangevalue3.value=value"></input>
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<h2>value</h2>
				<input type="text" id="rangevalue3" name="rangevalue3" value="<?php echo $scores['et_score'];?>" style="width: 50px">
				</div>
				<br>

				<h1><a href="#" style="color: black; font-size: 20px" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="Cultural history is the study of cultural tradition, historical experiences and experiences of ordinary people in the past.">
				Cultural History
				</a></h1>

				<div style="display: inline-block;">
				<h2><a href="#" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="Knowledge in traditions and religions practiced by humans (e.g. Christmas, new year, sinterklaas, Hanukkah, Judaism, Islam, Christianity, etc.)">
				Tradition and religion
				</a></h2>				

				<input id="rangeinput" type="range" min="1" max="5" value="<?php echo $scores['tr_score'];?>" style="width: 320px" onchange="rangevalue4.value=value"></input>
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<h2>value</h2>
				<input type="text" id="rangevalue4" name="rangevalue4" value="<?php echo $scores['tr_score'];?>" style="width: 50px">
				</div>
				<br>

				<div style="display: inline-block;">
				<h2><a href="#" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="Knowledge in various visual/performing arts (e.g. paintings, architecture, sculptures, dancing, theatre, music, etc.)">
				Art
				</a></h2>				

				<input id="rangeinput" type="range" min="1" max="5" value="<?php echo $scores['a_score'];?>" style="width: 320px" onchange="rangevalue5.value=value"></input>
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<h2>value</h2>
				<input type="text" id="rangevalue5" name="rangevalue5" value="<?php echo $scores['a_score'];?>" style="width: 50px">
				</div>

				<br>

				<div style="display: inline-block;">
				<h2><a href="#" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. WWII, Chernobyl, Assassination of Abraham Lincoln, 9/11, Moon landing, etc.">
				Historical events
				</a></h2>			

				<input id="rangeinput" type="range" min="1" max="5" value="<?php echo $scores['he_score'];?>" style="width: 320px" onchange="rangevalue6.value=value"></input>
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<h2>value</h2>
				<input type="text" id="rangevalue6" name="rangevalue6" value="<?php echo $scores['he_score'];?>" style="width: 50px">
				</div>

				<br>

				<div style="display: inline-block;">
				<h2><a href="#" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="Knowledge in how people lived their daily lives in the past and what for practices/life-styles they had (e.g. rich, poor, minorities, majority, family, honesty, bisexual, heterosexual, homosexual, smoking, alcohol consumption, drugs, etc.)">
				Life-style/Practices
				</a></h2>				

				<input id="rangeinput" type="range" min="1" max="5" value="<?php echo $scores['lp_score'];?>" style="width: 320px" onchange="rangevalue7.value=value"></input>
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<h2>value</h2>
				<input type="text" id="rangevalue7" name="rangevalue7" value="<?php echo $scores['lp_score'];?>" style="width: 50px">
				</div>

				<br>
				<div style="display: inline-block;">
				<h2><a href="#" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. the relationship among minorities and the majority, a groups position/values, customs which represent how such a group would think and behave, Interaction among members of certain social groups/positions">
				Social structures
				</a></h2>				

				<input id="rangeinput" type="range" min="1" max="5" value="<?php echo $scores['s_score'];?>" style="width: 320px" onchange="rangevalue8.value=value"></input>
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<h2>value</h2>
				<input type="text" id="rangevalue8" name="rangevalue8" value="<?php echo $scores['s_score'];?>" style="width: 50px">
				</div>
				<br>
				<h1><a href="#" style="color: black; font-size: 20px" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="Locations focuses on the places scences are recorded such as the city, street, or structure.">
				Locations
				</a></h1>
				<div style="display: inline-block;">
				<h2><a href="#" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. Netherlands, America, United Kingdom, etc.">
				Country
				</a></h2>				

				<input id="rangeinput" type="range" min="1" max="5" value="<?php echo $scores['co_score'];?>" style="width: 320px" onchange="rangevalue9.value=value"></input>
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<h2>value</h2>
				<input type="text" id="rangevalue9" name="rangevalue9" value="<?php echo $scores['co_score'];?>" style="width: 50px">
				</div>
				<br>
				<div style="display: inline-block;">
				<h2><a href="#" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. Amsterdam, New York, Berlin, Moskou, Lelystad, etc.">
				City
				</a></h2>				

				<input id="rangeinput" type="range" min="1" max="5" value="<?php echo $scores['ci_score'];?>" style="width: 320px" onchange="rangevalue10.value=value"></input>
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<h2>value</h2>
				<input type="text" id="rangevalue10" name="rangevalue10" value="<?php echo $scores['ci_score'];?>" style="width: 50px">
				</div>
				<br>
				<div style="display: inline-block;">
				<h2><a href="#" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. Kalverstraat, P.C. Hooftstraat, Kinkerstraat, Broadway, etc.">
				Street
				</a></h2>			

				<input id="rangeinput" type="range" min="1" max="5" value="<?php echo $scores['str_score'];?>" style="width: 320px" onchange="rangevalue11.value=value"></input>
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<h2>value</h2>
				<input type="text" id="rangevalue11" name="rangevalue11" value="<?php echo $scores['str_score'];?>" style="width: 50px">
				</div>
				<br>
				<div style="display: inline-block;">
				<h2><a href="#" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="Knowledge of famous structures in the world (e.g. Rijksmuseum, Anne Frank House, Empire State Building, Brooklyn Bridge, etc.)">
				Structures
				</a></h2>	
				<input id="rangeinput" type="range" min="1" max="5" value="<?php echo $scores['st_score'];?>" style="width: 320px" onchange="rangevalue12.value=value"></input>
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<h2>value</h2>
				<input type="text" id="rangevalue12" name="rangevalue12" value="<?php echo $scores['st_score'];?>" style="width: 50px">
				</div>


		                <br><br><br>

				<input type="submit" value="Submit scores" name="insert" id="insert" class="btn btn-primary" style="width: 320px;"></input>
				<h1 style="color: white">_</h1>
				</div>
				</form>

				
				
		</div>

		</div><!--//row-->
	</div>
</div><!--//site container-->

<?php include('snippets/footer.php');  ?>

