<?php 
	//insert this view
	include('snippets/header.php'); 
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>


<div class="site-container site-main" style="margin-top: 50px;">
	<div class="container">
		<div class="row no-gutter site-main-holder">
			<form class="col-md-6 col-md-offset-3" action="<?php print $_SERVER['REQUEST_URI'];?>" method="post">
					<div class="panel panel-default">
						<div class="panel-body">

							<p style="font-size: 20px;font-weight: bold">Log in</p>

							<div class="form-group input-group-md">
								<label for="gebruikersnaam">E-mail</label>
								<input class="form-control" type="text" name="email" id="gebruikersnaam" placeholder="email@domein.nl" value="<?php echo $_POST['gebruikersnaam']; ?>" required>
							</div>
							<div class="form-group input-group-md">
								<label for="password">Wachtwoord</label>
								<input class="form-control"  type="password" name="password" id="password" required>
							</div>

							<div class="col-md-2 col-md-offset-8">
							<a href="<?php echo ROOT; ?>/signup/"> Sign Up</a>
							</div>

							<div class="col-md-2">
							<div class="form-group text-right">
								<input type="hidden" name="action"  value="login">
								<input type="hidden" name="next"  value="<?php echo rawurlencode($_GET['next']); ?>">
								<button class="btn btn-md btn-primary" name="submit_login" type="submit"><i class="fa fa-sign-in"></i>Log in</button>
							</div>
							</div>


								
						</div>
					</div>
				</form>			

		</div>
	</div>
</div><!--//site container-->


<?php include('snippets/footer.php');  ?>
