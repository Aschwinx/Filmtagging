<?php 
	//insert this view
	include('snippets/header.php'); 
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
		$('#insert').click(function(event){
			event.preventDefault();
			$.ajax({
				url: "<?php echo ROOT?>/ajax/signup.php",
				method: "post",
				data: $('#myForm').serialize(),
				dataType: "text",
				success: function(strMessage){
					$('#message').text(strMessage);

					if ($.trim(strMessage) == "empty") {
						$('#insert').attr('value','Fill required fields')
						$('#insert').attr('class','btn btn-warning btn-block')
						setTimeout(reset, 1000)					

					}
					else if ($.trim(strMessage) == "error"){
						$('#insert').attr('value','error')
						$('#insert').attr('class','btn btn-danger btn-block')
						setTimeout(reset, 1000)

					}
					else if ($.trim(strMessage) == "success"){
						$('#insert').attr('value','Account created')
						$('#insert').attr('class','btn btn-success btn-block')
						setTimeout(reset, 1000);						
						location.href = "<?php echo ROOT;?>/login/";	

					}

					function reset(){
                   				$('#insert').attr('value','Create account')
                   				$('#insert').attr('class','btn btn-primary btn-block')
                   			}					

				}
			})

		})
	})
</script>

<script>
	function hoverText1(s1){
		var s1	= document.getElementById(s1)
								
		if (s1.value == "Cinematography") {

			$('#hover1').attr('data-content','Cinematography is the art of motion-picture photography by recording light, either electronically, or chemically.')

			}     
		else if (s1.value == "Cultral History") {

			$('#hover1').attr('data-content','Cultural history is the study of cultural tradition, historical experiences and experiences of ordinary people in the past.')

			}  
		else if (s1.value == "Locations") {

			$('#hover1').attr('data-content','Locations focuses on the places scences are recorded such as the city, street, or structure.')

			}                    				
        }		
</script>


<div class="site-container site-main" style="margin-top: 50px;background-color: #f9f9f9">
	<div class="container">
	<div class='row'>

		<style type="text/css">
			h1 
			{	
				font-size: 30px;
			}

			h2 
			{	
				font-size: 20px;
				color: gray;
			}


		label{
				font-size: 15px;

			}
			b{
				font-size: 14px;
				color: gray;
				font-weight: lighter;
			}
			p{
				font-size: 15px;
			}


		</style>
		<div class="col-md-7 col-md-offset-2">
					

		<div class="panel panel-default">
						<div class="panel-body">
						<form id="myForm" method="post">						

							<div class="form-group input-group-md">
								<label for="gebruikersnaam">E-mail<font color="red">*</font></label>
								<input class="form-control" type="text" name="email" id="email" placeholder="email@domain.nl" value="<?php echo $_POST['gebruikersnaam'];?>">
							</div>
							<div class="form-group input-group-md">
								<label for="password">Password<font color="red">*</font></label>
								<input class="form-control" type="password" name="password" id="password">
							</div>
							<div class="form-group input-group-md">
								<label for="password">User Name<font color="red">*</font></label>
								<input class="form-control" name="userName" id="userName">
							</div>
							<div class="form-group input-group-md">
								<label for="password">Education<font color="red">*</font></label>
								<input class="form-control" name="education" id="education">
							</div>
							<div class="form-group input-group-md">
								<label for="password">Job<font color="red">*</font></label>
								<input class="form-control" name="job" id="job">
							</div>
							
							
				<label>
					Knowledge levels
				</label>
				<p>	
					Submit your knowledge on a scale from 1 to 5 for the underneath categories. (1: No knowledge, 2: Little knowledge, 3: General understanding, 4: Good understanding, 5: Expert).
				</p>
														

				<script>
					$(document).ready(function(){

					$('[data-toggle="popover"]').popover();   
					});
				</script>
				<h1 style="color: black; font-size: 15px;font-weight: bold;">Cinematography</h1>
				
				

				<div style="display: inline-block;">
				<label><h1 style="color: gray; font-size: 15px;font-weight: bold;">Lighting/Special effect techniques<a href="#" style="text-decoration: underline;font-size: 15px;font-weight: bold;margin-left: 10px" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. backlight, under lighting, fill light, key light, lens flare, soft light, stop motion, CGI, bullet time, green screen, practical effects, dolly zoom, etc.">
				info
				</a></h1></label>	

				<input id="rangeinput" type="range" min="1" max="5" value="1" style="width: 550px" onchange="rangevalue1.value=value"/>	
				</div>

				<div style="display: inline-block;margin-left: 15px">
				<p>value</p>
				<input type="text" id="rangevalue1" name="rangevalue1" value='1'  style="width: 50px">		
				</div>	

				<br>
				<div style="display: inline-block;">
				<label><h1 style="color: gray; font-size: 15px;font-weight: bold;">Camera movement techniques<a href="#" style="text-decoration: underline;font-size: 15px;font-weight: bold;margin-left: 10px" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. Camera Angle, Shot size, Camera movement, track, pan, zoom, tilt, crane, etc.">
				info
				</a></h1></label>				

				<input id="rangeinput" type="range" min="1" max="5" value="1" style="width: 550px" onchange="rangevalue2.value=value">
				</div>

				<div style="display: inline-block;margin-left: 15px">
				<p>value</p>
				<input type="text" id="rangevalue2" name="rangevalue2" value='1'  style="width: 50px">		
				</div>	

				<br>
				<div style="display: inline-block;">
				<label><h1 style="color: gray; font-size: 15px;font-weight: bold;">Editing/Transition techniques<a href="#" style="text-decoration: underline;font-size: 15px;font-weight: bold;margin-left: 10px" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. cut, cross-cutting, continuity cuts, montage, jump cut, flashback, dissolve, wipe, etc.">
				info
				</a></h1></label>			

				<input id="rangeinput" type="range" min="1" max="5" value="1" style="width: 550px" onchange="rangevalue3.value=value"></input>
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<p>value</p>
				<input type="text" id="rangevalue3" name="rangevalue3" value='1' style="width: 50px">		
				</div>	

				<br>
				<h1 style="color: black; font-size: 15px;font-weight: bold;">Cultural History</h1>

				<div style="display: inline-block;">
				<label><h1 style="color: gray; font-size: 15px;font-weight: bold;">Tradition and religion<a href="#" style="text-decoration: underline;font-size: 15px;font-weight: bold;margin-left: 10px" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="Knowledge in traditions and religions practiced by humans (e.g. Christmas, new year, sinterklaas, Hanukkah, Judaism, Islam, Christianity, etc.)">
				info
				</a></label>			

				<input id="rangeinput" type="range" min="1" max="5" value="1" style="width: 550px" onchange="rangevalue4.value=value"></input>
				</div>

				<div style="display: inline-block;margin-left: 15px">
				<p>value</p>
				<input type="text" id="rangevalue4" name="rangevalue4" value='1' style="width: 50px">		
				</div>	

				<br>

				<div style="display: inline-block;">
				<label><h1 style="color: gray; font-size: 15px;font-weight: bold;">Art<a href="#" style="text-decoration: underline;font-size: 15px;font-weight: bold;margin-left: 10px" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="Knowledge in various visual/performing arts (e.g. paintings, architecture, sculptures, dancing, theatre, music, etc.)">
				info
				</a></label>

				<input id="rangeinput" type="range" min="1" max="5" value="1" style="width: 550px" onchange="rangevalue5.value=value"></input>
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<p>value</p>
				<input type="text" id="rangevalue5" name="rangevalue5" value='1' style="width: 50px">		
				</div>	

				<br>
				<div style="display: inline-block;">
				<label><h1 style="color: gray; font-size: 15px;font-weight: bold;">Historical events<a href="#" style="text-decoration: underline;font-size: 15px;font-weight: bold;margin-left: 10px" data-toggle="popover" data-trigger="hover" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. WWII, Chernobyl, Assassination of Abraham Lincoln, 9/11, Moon landing, etc.">
				info
				</a></label>			

				<input id="rangeinput" type="range" min="1" max="5" value="1" style="width: 550px" onchange="rangevalue6.value=value"></input>
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<p>value</p>
				<input type="text" id="rangevalue6" name="rangevalue6" value='1' style="width: 50px">		
				</div>	

				<br>
				<div style="display: inline-block;">
				<label><h1 style="color: gray; font-size: 15px;font-weight: bold;">Life-style/Practices<a href="#" style="text-decoration: underline;font-size: 15px;font-weight: bold;margin-left: 10px" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="Knowledge in how people lived their daily lives in the past and what for practices/life-styles they had (e.g. rich, poor, minorities, majority, family, honesty, bisexual, heterosexual, homosexual, smoking, alcohol consumption, drugs, etc.)">
				info
				</a></label>				

				<input id="rangeinput" type="range" min="1" max="5" value="1" style="width: 550px" onchange="rangevalue7.value=value"></input>
				</div>

				<div style="display: inline-block;margin-left: 15px">
				<p>value</p>
				<input type="text" id="rangevalue7" name="rangevalue7" value='1' style="width: 50px">		
				</div>	
				<br>

				<div style="display: inline-block;">
				<label><h1 style="color: gray; font-size: 15px;font-weight: bold;">Social structures<a href="#" style="text-decoration: underline;font-size: 15px;font-weight: bold;margin-left: 10px" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. the relationship among minorities and the majority, a groups position/values, customs which represent how such a group would think and behave, Interaction among members of certain social groups/positions">
				info
				</a></label>				

				<input id="rangeinput" type="range" min="1" max="5" value="1" style="width: 550px" onchange="rangevalue8.value=value"></input>
				</div>
				<div style="display: inline-block;margin-left: 15px">
				<p>value</p>
				<input type="text" id="rangevalue8" name="rangevalue8" value='1' style="width: 50px">		
				</div>	

				<h1 style="color: black; font-size: 15px;font-weight: bold;">Locations</h1>

				<div style="display: inline-block;">
				<label><h1 style="color: gray; font-size: 15px;font-weight: bold;">Country<a href="#" style="text-decoration: underline;font-size: 15px;font-weight: bold;margin-left: 10px" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. Netherlands, America, United Kingdom, etc.">
				info
				</a></label>	

				<input id="rangeinput" type="range" min="1" max="5" value="1" style="width: 550px" onchange="rangevalue9.value=value"/>	
				</div>

				<div style="display: inline-block;margin-left: 15px">
				<p>value</p>
				<input type="text" id="rangevalue9" name="rangevalue9" value='1'  style="width: 50px">		
				</div>	

				<br>
				<div style="display: inline-block;">
				<label><h1 style="color: gray; font-size: 15px;font-weight: bold;">City<a href="#" style="text-decoration: underline;font-size: 15px;font-weight: bold;margin-left: 10px" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. Amsterdam, New York, Berlin, Moskou, Lelystad, etc.">
				info
				</a></label>				

				<input id="rangeinput" type="range" min="1" max="5" value="1" style="width: 550px" onchange="rangevalue10.value=value">
				</div>

				<div style="display: inline-block;margin-left: 15px">
				<p>value</p>
				<input type="text" id="rangevalue10" name="rangevalue10" value='1'  style="width: 50px">		
				</div>	
				<div style="display: inline-block;">
				<label><h1 style="color: gray; font-size: 15px;font-weight: bold;">Street<a href="#" style="text-decoration: underline;font-size: 15px;font-weight: bold;margin-left: 10px" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="e.g. Kalverstraat, P.C. Hooftstraat, Kinkerstraat, Broadway, etc.">
				info
				</a></label>	

				<input id="rangeinput" type="range" min="1" max="5" value="1" style="width: 550px" onchange="rangevalue11.value=value"/>	
				</div>

				<div style="display: inline-block;margin-left: 15px">
				<p>value</p>
				<input type="text" id="rangevalue11" name="rangevalue11" value='1'  style="width: 50px">		
				</div>	

				<br>
				<div style="display: inline-block;">
				<label><h1 style="color: gray; font-size: 15px;font-weight: bold;">Structure<a href="#" style="text-decoration: underline;font-size: 15px;font-weight: bold;margin-left: 10px" data-toggle="popover" data-trigger="hover" data-placement="right" data-content="Knowledge of famous structures in the world (e.g. Rijksmuseum, Anne Frank House, Empire State Building, Brooklyn Bridge, etc.)">
				info
				</a></label>				

				<input id="rangeinput" type="range" min="1" max="5" value="1" style="width: 550px" onchange="rangevalue12.value=value">
				</div>

				<div style="display: inline-block;margin-left: 15px">
				<p>value</p>
				<input type="text" id="rangevalue12" name="rangevalue12" value="1"  style="width: 50px">		
				</div>		

				<br>






				<br>
				<br>

				<div class="form-group input-group-md">
					<label for="password">Relevant Background Knowledge</label>
					<textarea class="form-control" placeholder="Information that might be relevant to the platform such as 'Watch alot of old movies', 'Have annotated before', 'Know alot about Amsterdam', 'I am a enthusiastic hobby/professional photographer', etc."  rows="5" name="background" id="background"></textarea>
				</div>
				<br>


				<input type="submit" value="Create account" name="insert" id="insert" class="btn btn-primary btn-block"></input>


							</form>	
						</div>
					</div>
					</div>



		

		

		</div><!--//row-->
	</div>
</div><!--//site container-->

<?php include('snippets/footer.php');  ?>

