<?php 
	//insert this view
	include('snippets/header.php'); 
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
 <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	<style type="text/css">
			h1 
			{	
				font-size: 30px;
			}

			h2 
			{	
				font-size: 20px;
				color: gray;
			}


		label{
				font-size: 14px;

			}
			b{
				font-size: 13px;
				color: gray;
				font-weight: lighter;
			}

		</style>


<div class="site-container site-main" style="margin-top: 50px;background-color: #f9f9f9">
	<div class="container">
	<div class='row'>
		<div class="col-md-9 col-md-offset-1" style="margin-left: 15px;margin-top: 15px">


		<?php echo "<h1>".$user["userName"]."</h1>";?><br>
		
		<label style="font-size: 18px">id:<?php echo " "."<b style='font-size: 16px'>".$user["id"]."</b>";  ?></label><br>
		<label style="font-size: 18px">Education:<?php echo " "."<b style='font-size: 16px'>".$user["education"]."</b>";  ?></label><br>
		<label style="font-size: 18px">Job:<?php echo " "."<b style='font-size: 16px'>".$user["job"]."</b>";  ?></label><br><br>
		<label style="font-size: 18px">Relevant Background Knowledge<?php echo " "."<br>"."<b style='font-size: 16px'>".$user["background"]."</b>";  ?></label><br><br>

		<div class="col-md-3">
		<label>Lighting/Special effect:<?php echo " "."<b>".$user["ls_score"]."/5"."</b>";  ?></label><br><br>
				
		</div>
		<div class="col-md-3">
		<label>Camera movement:<?php echo " "."<b>".$user["cm_score"]."/5"."</b>";  ?> </label><br><br>
		</div>

		<div class="col-md-3">
		<label>Editing/Transition:<?php echo " "."<b>".$user["et_score"]."/5"."</b>";  ?></label><br><br>
				
		</div>
		<div class="col-md-3">
		<label>Tradition and Religion:<?php echo " "."<b>".$user["tr_score"]."/5"."</b>";  ?> </label><br><br>
		</div>

		<div class="col-md-3">
		<label>Art:<?php echo " "."<b>".$user["a_score"]."/5"."</b>";  ?></label><br><br>
				
		</div>
		<div class="col-md-3">
		<label>Historical events:<?php echo " "."<b>".$user["he_score"]."/5"."</b>";  ?> </label><br><br>
		</div>

		<div class="col-md-3">
		<label>Life-style/Practices:<?php echo " "."<b>".$user["lp_score"]."/5"."</b>";  ?></label><br><br>
				
		</div>
		<div class="col-md-3">
		<label>Social structures:<?php echo " "."<b>".$user["s_score"]."/5"."</b>";  ?> </label><br><br>
		</div>

		
		<div class="col-md-3">
		<label>Country:<?php echo " "."<b>".$user["co_score"]."/5"."</b>";  ?> </label><br><br>
		</div>

		<div class="col-md-3">
		<label>City:<?php echo " "."<b>".$user["ci_score"]."/5"."</b>";  ?> </label><br><br>
		</div>

		<div class="col-md-3">
		<label>Street:<?php echo " "."<b>".$user["str_score"]."/5"."</b>";  ?> </label><br><br>
		</div>

		<div class="col-md-3">
		<label>Structure:<?php echo " "."<b>".$user["st_score"]."/5"."</b>";  ?> </label><br><br>
		</div>

		<label style="font-size: 18px"><?php echo $user["userName"];?> annotations </label>		
		<div class="col-md-12" style="margin-top: 10px">
		<table id="data_output" class="table table-bordered table-hover table-condensed">
		<tr style="background-color: white">
		<th>Tag</th>
		<th>Video title</th>
		<th>Category</th>
		<th>Subcategory</th>
		<th>Classification</th>
		</tr>
		
		<?php 
			foreach ($rows as $row) {
				echo "<tr style='background-color: white'>";
				echo "<td>".$row['tag_text']."</td>"."<td>".$row['video_name']."</td>"."<td>".$row['c_name']."</td>"."<td>".$row['sc_name']."</td>"."<td>".$row['class']."</td>";
				echo "</tr>";
			};
		 ?>	
			
		</table>
		</div>	

		</div>	

		</div><!--//row-->
	</div>
</div><!--//site container-->

<?php include('snippets/footer.php');  ?>
