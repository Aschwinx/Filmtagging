<?php 
	//insert this view
	include('snippets/header.php'); 
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
 <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

	<style type="text/css">
			h1 
			{	
				font-size: 30px;
			}

			h2 
			{	
				font-size: 20px;
				color: gray;
			}


		label{
				font-size: 14px;

			}
			b{
				font-size: 13px;
				color: gray;
				font-weight: lighter;
			}

		</style>


<div class="site-container site-main" style="margin-top: 50px;background-color: #f9f9f9">
	<div class="container">
	<div class='row'>
		<div class="col-md-9 col-md-offset-1">

		<video width="100%" height="500" style="margin-bottom: 10px" controls>
   			<source src="<?php echo $videos["source"]?>">" type="video/mp4">
   			<source src="movie.ogg" type="video/ogg">
 			Your browser does not support the video tag.
		</video>

		<div class="col-md-12">

				<?php echo "<h1>".$videos["title"]."</h1>"."<h2>".$videos["director"]."</h2>".$videos["description"];?>

				<br>
				<br>

				<div class="col-md-12" style="margin-bottom: 20px">
				<div class="col-md-3">
				<label>Country:<?php echo " "."<b>".$videos["country"]."</b>";  ?></label><br><br>
				
				</div>
				<div class="col-md-3">
				<label>Producer:<?php echo " "."<b>".$videos["producer"]."</b>";  ?> </label><br><br>
				
				</div>
				<div class="col-md-3">
				<label>Year:<?php echo " "."<b>".$videos["year"]."</b>";  ?> </label><br>
				
				</div>
				<div class="col-md-3">
				<label>Language:<?php echo " "."<b>".$videos["language"]."</b>";  ?></label><br><br>
				
				</div>
				</div>
		
		
		</div>

		<div class="col-md-12">
		<table id="data_output" class="table table-bordered table-hover table-condensed">
		<tr style="background-color: white">
		<th>Tag</th>
		<th>Category</th>
		<th>Subcategory</th>
		<th>Classification</th>
		<th>Start Time</th>
		<th>End Time</th>
		</tr>
		
		<?php 
			foreach ($rows as $row) {
				echo "<tr style='background-color: white'>";
				echo "<td>".$row['tag_text']."</td>"."<td>".$row['c_name']."</td>"."<td>".$row['sc_name']."</td>"."<td>".$row['class']."</td>"."<td>".$row['start_time']."</td>"."<td>".$row['end_time']."</td>";
				echo "</tr>";
			};
		 ?>	
			
		</table>
		</div>	
		
		</div><!--//row-->
	</div>
</div><!--//site container-->

<?php include('snippets/footer.php');  ?>
